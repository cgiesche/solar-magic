;========================================
; Shatter After Touch: Bounce Sprite
; By Arinsu
;========================================

!do_shatter     = 1         ;   whether to display shatter particles. 0 - no, 1 - yes
!show_smoke     = 1         ;   whether to show smoke after shattering. 0 - no, 1 - yes

; Bounds for when the player if off the block.
!left_boundary  = $000D
!right_boundary = $000D
!top_boundary   = $0020
!bot_boundary   = $0010

!yoshi_offset   = $0010

;---

print "MAIN ",pc
shatter_aftertouch:
    LDA $9D
    BNE .return
    LDA !bounce_x_high,x
    XBA
    LDA !bounce_x_low,x
    REP #$21
    STA $9A
    LDA $94
    ADC.w #!left_boundary
    CMP $9A
    BMI .shatter_block_8
    LDA $94
    SEC
    SBC.w #!right_boundary
    CMP $9A
    SEP #$20
    BPL .shatter_block
    LDA !bounce_y_high,x
    XBA
    LDA !bounce_y_low,x
    REP #$21
    STA $98
    LDA $96
    ADC.w #!top_boundary
    LDY $187A|!addr
    BEQ +
    ADC.w #!yoshi_offset
+   CMP $98
    BMI .shatter_block_8
    LDA $96
    SEC
    SBC.w #!bot_boundary
    CMP $98
    SEP #$20
    BPL .shatter_block
.return
    RTL

.shatter_block_8
    SEP #$20
.shatter_block
    STZ !bounce_num,x
    if !do_shatter
        LDA.b #$02|bank(!bank)
        PHA
        PLB
        TDC
        JSL $028663|!bank
    endif
    if !show_smoke
        LDA #$1B
        STA $02
        LDA #$01
        %SpawnSmoke()
        BCS .no_smoke
        LDA $98
        STA $17C4|!addr,y
        LDA $9A
        STA $17C8|!addr,y
    .no_smoke
    endif
    LDA !bounce_table,x
    ASL
    ROL
    STA $1933|!addr
    LDA #$02
    STA $9C
    JML $00BEB0|!bank

