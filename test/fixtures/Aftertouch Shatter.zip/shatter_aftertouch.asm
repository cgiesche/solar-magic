;========================================
; Shatter After Touch
; Original by HammerBrother
; Remade by Arinsu
;
; Acts like: 100 or 130
;========================================

!cracked_tile   = $0601     ;   Map16 tile to change to after touching the block.
!bounce_sprite  = $01       ;   Custom bounce sprite number of the included bounce sprite.

;---

db $42
JMP return : JMP shatter_aftertouch : JMP return
JMP return : JMP return : JMP return : JMP return
JMP shatter_aftertouch : JMP return : JMP return

shatter_aftertouch:
    LDA $7D
    BMI return
    REP #$21
    LDA $98
    AND #$FFF0
    SBC #$001B
    CMP $96
    SEP #$20
    BCC return

    LDA.b #!bounce_sprite+$08
    LDY #$00
    TYX
    %spawn_bounce_sprite()

    REP #$10
    LDX.w #!cracked_tile
    %change_map16()
    SEP #$10

return:
    RTL

print "A block which shatters after the player gets off it."