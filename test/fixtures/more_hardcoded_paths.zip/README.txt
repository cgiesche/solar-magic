More Hardcoded Paths patch by Kevin
-------------------------------------------------------------

This patch allows you to edit/remove vanilla hardcoded paths on the Overworld and add your own.

To use it, edit the tables in "more_hardcoded_paths_tables.asm":
- "levels": here you add the levels that should be connected with a hardcoded path. Each line should have 2 levels (or 1 to have a one-way path). To define a level use the level(XXX) function, since level numbers are handled kinda weirdly by the game.
- "directions": which direction to press to activate the hardcoded path for each entry in the "levels" table (!Up,!Down,!Left,!Right). Each line should have 2 values (or 1 to have a one-way path).
- "paths": here you add the layer 1 tiles that form the path between the levels (including the tile for the destination level). If you added a pair in .XX under levels, then you'll need to add paths in .XX_1 and .XX_2 (to go from one level to the other and viceversa). Usually you want the two paths that connect two levels to be the same (but in reverse order), but it doesn't have to be so (they also don't need to have the same length).
- "animation": it can be used to override Mario's animation for any of the tiles in the hardcoded path, to either swimming or climbing. This can be used to have some fancier water/climbing paths: since some water path tiles don't exist in vanilla and climbing is only vertical, this allows you more freedom, for example horizontal climbing. Since 1.1, it can also be used to force Mario to go behind layer 1 tiles, which can be used to change his priority when passing through certain tiles depending on the path he takes. Usually you'll want to to this also for the tile before and after where the priority change should happen, since Mario's graphics will overlap with the previous and next tile while walking on a path.

Note: make sure "levels" and "directions", and "paths" and "animation" have the same number of values in each row!

Then, patch "more_hardcoded_paths.asm" with Asar (not the tables file!), making sure that the two asm files are in the same folder. When you make some changes to the tables, just repatch the main asm file.

The first 5 paths included are the vanilla ones, which you can freely edit or remove altogether. Note that the CI2-Pipe path is special in that it checks for the pipe's position on the Overworld, rather than the level number (since it's just 0 in vanilla). This is done by using $FF in the levels table, and by defining the positions separately. If you don't want this behavior, edit the $FF to a different level number. If you want to keep it but edit the position of the path, then edit the CI2 position tables at the top of the file.

If you need more than 16 paths, you can add entries as you wish. For example, to add one after .0F, add .10: under "levels" and "directions", .10_1: and .10_2: under "paths" and "animation", but you'll also need to add .10: dw %offsets(10) in the "offset" table. You can have up to 128 hardcoded paths.

Note that connections don't have to be bidirectional: you can make one-way paths by having some unused level as the starting point for the second part of a path, and putting a random value (like a 0) in the .XX_2 row in the other tables, so that only the first part will actually be used in game. Or, if you want 2 one-way paths, just put them as the two parts of the same path (the two parts don't need to refer to the same path but in opposite directions!). Just remember that to function correctly, all the entries in the tables should have two parts in them (so, 2 values in "levels" and "directions", and the .XX_1 and .XX_2 rows in "paths" and "animation" filled with something).

Also note that you can have multiple hardcoded paths from/to the same level (just make sure they all use different directions from it, otherwise only one of them will work obviously).

Finally, actions that are activated by walking on a certain tile still work if that tile is in a hardcoded path: for example, tiles 0x4E, 0x4F and 0x50 will still trigger the jumping fish if they're used in a hardcoded path.

-------------------------------------------------------------
Changelog:

- v1.0: initial version
- v1.1: added option to change Mario's priority during a path
