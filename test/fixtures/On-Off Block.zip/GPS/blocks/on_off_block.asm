db $37

JMP MarioBelow : JMP MarioAbove : JMP MarioSide
JMP SpriteV : JMP SpriteH
JMP Cape : JMP Fireball
JMP MarioCorner : JMP MarioInside : JMP MarioHead
JMP WallRun : JMP WallFeet

!bounce_num			= $03			; See RAM $1699 for more details.
!bounce_custom		= 1				; Set this to 1 if you want to use a custom bounce sprite
!bounce_block		= $FF			; See RAM $9C for more details. Can be set to $FF to change the tile manually
!bounce_tile		= $FF			; The tile number of the bounce sprite. If set to $FF, it'll use a hardcoded tile set within the sprite
!bounce_properties	= $07			; YXPPCCCT properties
!bounce_cooldown	= 8				; Non-zero enables it: How long the block can't be immediately retriggered. Requires ON/OFF Cooldown to be installed.

; If !bounce_block is set to $FF (or to $00 and !bounce_custom is 0)
!bounce_map16		= $FFFF			; The tile it should turn into (if bounce). $8000-$FFFF = don't change

!allow_duplication	= 1				; By default, custom blocks are immune to block duplication
									; But it is possible to still enable them if you recreate
                                    ; the code which handles interaction with ?-blocks.

!sound_id           = $0B           ; Which sound effect to play when the block gets triggered. Set to 0 to disable it.
!sound_port         = $1DF9         ; The port of the above SFX

!trigger_above		= 0				; The block can be trigger with a spinjump like SMW turn blocks can.
!trigger_fire		= 0				; The block can be triggered with a fireball
!trigger_cape		= 1				; The block can be trigger with a cape swing
!trigger_sprite		= 1				; The block can be trigger with a kicked sprite

!one_way_switch		= 0				; If set to 1: Make the switch one-way i.e. it can only turn on to off or vice versa.
									; If you want the switch to be single use, change it to a different block entirely.
!one_way_inverted	= 0				; 0 = only turns on; 1 = only turns off

; If !bounce_cooldown isn't 0
!cooldown_timer		= $18F6|!addr	; Must be set to the same value as the cooldown patch.


; Internal defines, do not change!
!bounce_offset = $08		; Since GPS hasn't been updated yet, I have to define it manually
!bounce_enabled #= or(!bounce_custom, !bounce_num)

MarioAbove:
MarioCorner:
if !trigger_above
	LDA $140D|!addr		; Must be spin jumping
	BEQ Return
	LDA $7D				; Must be falling
	BMI Return
	LDA $90				; Must be at top half of the block
	CMP #$08
	BCS Return
	LDA $8F				; Must be in the air (previous frame)
	BEQ Return
	LDA #$D0			; Bounce player
	STA $7D
	LDA #$03			; Bounce downwards
JMP DoBounce
endif

if not(!trigger_sprite)
SpriteV:
SpriteH:
endif
if not(!trigger_cape)
Cape:
endif
if not(!trigger_fire)
Fireball:
endif
MarioHead:
MarioSide:
MarioInside:
WallRun:
WallFeet:
Return:
RTL

if !trigger_fire
Fireball:
	LDA $0F
	STA $1933|!addr
	LDA #$01				; Destroy fireball
	STA $1DF9|!addr
	LDA #$0F
	STA $176F|!addr,x
	LDA #$01
	STA $170B|!addr,x
BRA UpwardBounce
endif

if !trigger_cape && not(!bounce_enabled) && not(!bounce_cooldown)
Cape:
	LDA $0F
	STA $1933|!addr
	LDA $13					; Only trigger every fourth frame
	AND #$02
	BNE UpwardBounce
RTL
endif

if not(!bounce_enabled) && not(!bounce_cooldown)
MarioBelow:
	LDA $7D					; Must move upwards to trigger
	BMI UpwardBounce
RTL
endif

if !trigger_sprite
SpriteH:
	LDA !15A0,x
	BNE Return
	LDA !E4,x
	SEC : SBC $1A
	CLC : ADC #$14
	CMP #$1C
	BCC Return
	%check_sprite_kicked_horiz_alt()
	BCC Return
	LDA #$05
BRA SpriteShared

SpriteV:
	LDA !14C8,x
	SEC : SBC #$09
	CMP #$02
	BCS Return
	LDA !AA,x
	BPL Return
	LDA !1588,x
	AND #$03
	BNE Return
if !allow_duplication
	; This code is janky because it doesn't fully replicate
	; the interaction points. This dissonance causes the
	; game to duplicate blocks if you manage to kick a
	; shell at a block when their tops are touching each
	; other.
	LDA !E4,x
	CLC : ADC #$08
	STA $9A
	LDA !14E0,x
	ADC #$00
	STA $9B
	LDA !D8,x
	AND #$F0
	STA $98
	LDA !14D4,x
	STA $99
endif

	LDA #$08
SpriteShared:
	STA !1FE2,x
	%sprite_block_position()
    BRA UpwardBounce
endif

if !trigger_cape && or(!bounce_enabled, !bounce_cooldown)
Cape:
	LDA $0F
	STA $1933|!addr
endif
if or(!bounce_enabled, !bounce_cooldown)
MarioBelow:
endif
UpwardBounce:
	LDA #$00

DoBounce:
if !bounce_enabled
	if !one_way_switch || !bounce_cooldown
		XBA
		if !one_way_switch
			LDA $14AF|!addr
			if !one_way_inverted
				BNE .Return
			else
				BEQ .Return
			endif
		endif
		if !bounce_cooldown
			LDA !cooldown_timer
			BNE .Return
			LDA.b #!bounce_cooldown*4
			STA !cooldown_timer
		endif
		XBA
	endif
	PHX
	PHY
	TAY
	if !bounce_custom
		LDA #!bounce_num+!bounce_offset
	else
		LDA #!bounce_num
	endif
	if !bounce_block == $FF
		LDX #$00
	else
		LDX #!bounce_block
	endif
	%spawn_bounce_sprite()
	if !bounce_block == $FF
		if !bounce_map16 >= $8000
			LDA $03
			STA $16C1|!addr,y	; !bounce_map16_low
			LDA $04
			STA $1968|!addr,y	; !bounce_map16_high
		else
			LDA.b #!bounce_map16
			STA $16C1|!addr,y	; !bounce_map16_low
			LDA.b #!bounce_map16>>8
			STA $1968|!addr,y	; !bounce_map16_high
		endif
	else
	LDA #$FF
	STA $1968|!addr,y
	endif
	if !bounce_tile != $FF
	LDA #!bounce_tile
	STA $196C|!addr,y		; !bounce_table_3
	endif
	LDA #!bounce_properties
	STA $1901|!addr,y

	PLY
	PLX
else
	if !one_way_switch
		LDA $14AF|!addr
		if !one_way_inverted
			BNE .Return
		else
			BEQ .Return
		endif
	endif
	if !bounce_cooldown
		LDA !cooldown_timer
		BNE .Return
		LDA.b #!bounce_cooldown*4
		STA !cooldown_timer
	endif
	LDA $14AF|!addr
	EOR #$01
	STA $14AF|!addr
	if !bounce_map16 < $8000
		PHX
		REP #$10
		LDX #!bounce_map16
		%change_map16()
		SEP #$10
		PLX
	endif
endif
if !sound_id
	LDA #!sound_id
	STA !sound_port|!addr
endif
.Return
RTL

if !one_way_switch
	if !one_way_inverted
	print "An block which changes the switch state from off to on."
	else
	print "An block which changes the switch state from on to off."
	endif
else
print "An block which changes the switch state from on to off and vice versa."
endif
