                      On/Off Blocks
                    by MarioFanGamer
            ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

What does this block do?
----------------------------------------------------------
It's a replica of the on/off blocks from Super Mario
World. It's actually a more versatile recreation while
still maintaining a bounce animation (though you can
disable that).

How do I insert them?
----------------------------------------------------------
This requires two separate tools: GPS and PIXI. GPS is
necessary to handle the block which interacts with Mario
while PIXI is used for the animation.

In particular, you need PIXI v1.40 as that's the first
version which supports custom bounce sprites. There is no
support to older versions nor support to the Custom Bounce
Sprites patch

So many settings!
----------------------------------------------------------
There is a reason it took me so long to create this. :)

I've separated the defines into multiple categories:
- "bounce" refers to the bounce sprite itself including
  number, custom and properties (other appearance).
  Setting both "bounce_num" and "bounce_custom" to zero
  disables the bounce animation whereas "bounce_tile"
  is explained below.
  There also is "bounce_cooldown" which is intended to be
  used for the ON/OFF Cooldown patch. Strictly speaking,
  you only need the UberASM file but I recommend you to
  also use the patch for consistency with the vanilla
  blocks. It's strongly recommend to use it for bounceless
  blocks with how easy it is to retrigger the blocks.
- "trigger" refers to how and when the block gets
  triggered. By default, touching the block from below is
  enabled but you can also trigger them with a cape like
  or thrown enemy like the original blocks but also per
  spin jump like SMW's turn blocks and fireballs as some
  custom blocks allow you this.
- "sound" refers to the sound which plays when you trigger
  the block. Setting !sound_id to 0 prevents a sound from
  playing.
  Originally used when you trigger a bounceless On/Off
  block, I also enabled it for bounce ones since I
  realised that this also happens with the original
  blocks.
- "one_way" is for the implementation of one-way switches,
  not to be confused with single-use switches. That means,
  you can only use the switch if it's at the right state
  which causes the switch to be able to only from on to
  off but not vice versa (or inverted i.e. off to on but
  not on to off).
  If you want an actual single-use switch, please set
  "bounce_block" and "bounce_map16" for your own likings.
- "allow_duplication" is the odd one out but it basically
  is a setting which allows you to execute block
  duplication which otherwise doesn't work (as well) in
  custom blocks.

What the heck are !bounce_tile and !BounceTile?
----------------------------------------------------------
It's the tile GFX of the bounce sprite. The way bounce
sprites work is that although they use a dynamic palette,
their tile number is hardcoded within their code.
This is how the previous version of the note blocks used
to be, in fact.

However, PIXI reserves some additional general purpose
tables for bounce sprites (including one which is defined
for the Map16 tile they change into, to bypass the limited
change Map16 routine of SMW), one of which can be used to
set the GFX tile for the bounce sprite.

In fact, had Nintendo reserved another table for bounce
sprite GFX, they'd only need three separate bounce sprites
(generic, turn blocks and on/off block).

The way they work is that you can disable one system and
use the other by setting ONE (and only one!) of these
defines to be $FF.
If !bounce_tile in the blocks is set to $FF, it means the
bounce sprite uses hardcoded tiles and don't store to the
general purpose table (which then can be used for other
suff, for example), otherwise this will be the tile the
bounce sprite will appear. In order for that to apply,
though, make sure !BounceTile in the sprite is set to $FF,
otherwise it'll use whatever tile is defined there.
I chose $FF because most bounce sprites are 16x16 and it's
unlikely for such a sprite to use a tile in this location.

Do I must give you credits?
----------------------------------------------------------
Most of the code is reused from my other bounce blocks,
no.

Have you done everything by yourself?
----------------------------------------------------------
The code of the block has been adapted from my Question
Mark Blocks, itself based of SMW code. The sprites also
are modified from the vanilla game.

Why did you make this block?
----------------------------------------------------------
Ever since PIXI v1.40, the first version which supports
the insertion of custom bounce sprites, got released, I
had the idea to reacreate the on/off block (particularly
because custom bounce sprites comes with one on its own).

It's the creation of Cavern Collectathon which inspired me
to finally create this block, though.
This hack focuses on various abilities with one of them
being an ability similar to Stone Kirby or the statue
transformation of Tanookie Mario. Among others, it's
ability is to trigger on/off switches which I quickly made
(though the other coder has started it before with a
non-bouncing animation but failed the interaction part).

I've got a question!
----------------------------------------------------------
Post it to the forums. In the worst case, you can PM me.

Is that really all?
----------------------------------------------------------
Move along, nothing to see here.
