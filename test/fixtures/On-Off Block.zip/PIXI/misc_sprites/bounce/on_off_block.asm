!SwitchSfx = $0B                ; The sound effect to play when switching. Set to zero to disable it.
!SwitchSfxPort = $1DF9          ; The port of the above

!BounceTile = $8A               ; The GFX tile for the bounce sprite.


print "MAIN",pc
if !BounceTile != $FF           ;
    LDA #!BounceTile            ; Draw note block tile
else                            ;
    LDA !bounce_table_3,x       ; Draw the assigned tile.
endif                           ;
    %BounceGenericDraw()        ;
                                ;
    LDA $9D                     ; Return if not frozen
    BEQ .Continue               ;
RTL                             ;
                                ;
.Continue:                      ;
    LDA !bounce_init,x          ; Is the sprite freshly spawned?
    BNE .NoInit                 ;
                                ;
    INC !bounce_init,x          ;
    %InvisibleMap16()           ; Spawn invisible tile
    %EraseCoinAbove()           ; Remove coin
                                ;
.NoInit:                        ;
    %UpdatePos()                ;
    %SetSpeed()                 ;
                                ;
    LDA !bounce_timer,x         ;
    BNE .NotFinished            ;
                                ;
    %BounceSetupMap16()         ;
    LDA !bounce_map16_high,x    ; Basically, Map16 pages +$80 are undefined (for foreground)
    BMI .Vanilla                ; so I use it to determine whether any block can be changed
    XBA                         ; or using SMW's limited change block routine.
    LDA !bounce_map16_low,x     ;
    %ChangeMap16()              ;
    BRA .ChangeTileEnd          ;
                                ;
.Vanilla:                       ;
    LDA !bounce_map16_low,x     ;
    STA $9C                     ;
    JSL $00BEB0|!bank           ;
                                ;
.ChangeTileEnd:                 ;
if !SwitchSfx                   ;
    LDA #!SwitchSfx             ; Play switch SFX
    STA !SwitchSfxPort|!addr    ;
endif                           ;
    LDA $14AF|!addr             ; Change switch state
    EOR #$01                    ;
    STA $14AF|!addr             ;
                                ;
    STZ !bounce_num,x           ; Terminate itself
                                ;
.NotFinished:                   ;
RTL                             ;
