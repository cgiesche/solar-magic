;===============================================================================
; Shared routines and macros.
;===============================================================================

;===============================================================================
; Macro to push the current code's DB to the stack and set the DBR to label's
; bank.
; Note: remember to PLB when finished!
;===============================================================================
macro set_dbr(label)
?-  pea.w bank(<label>)|(bank(?-)<<8)
    plb
endmacro

;===============================================================================
; God awful function to find the RTL location in various SMW banks
; It returns 0 if the bank is not supported
;===============================================================================
function __rtl(x) = \
    select(equal(x, $00), $0084CF,\
    select(equal(x, $01), $0180CA,\
    select(equal(x, $02), $02B889,\
    select(equal(x, $03), $03827F,\
    select(equal(x, $04), $048575,\
    select(equal(x, $05), $058125,\
    select(equal(x, $07), $07FC51,\
    select(equal(x, $0C), $0C9399,\
    select(equal(x, $0D), $0DA105,\
    0)))))))))

;===============================================================================
; Macro to JSL to a routine that ends in RTS.
;===============================================================================
macro jsl_to_rts(routine)
    !__rtl = __rtl(bank(<routine>)&$7F)
    assert !__rtl,\
        "jsl_to_rts not supported for bank $", hex(bank(<routine>)&$7F)
    assert read1(!__rtl) == $6B,\
        "Found $", hex(read1(!__rtl)), " at ROM $", hex(!__rtl), ", expected $6B"
    
    phk : pea.w (?+)-1
    pea.w !__rtl-1
    jml <routine>|!bank
?+
    undef "__rtl"
endmacro

;===============================================================================
; Macro to JSL to a routine that ends in RTS.
; Also sets up the DBR to the routine's bank.
;===============================================================================
macro jsl_to_rts_db(routine)
    %set_dbr(<routine>)
    %jsl_to_rts(<routine>)
    plb
endmacro

;===============================================================================
; Macro to load the current level number ($13BF).
; Calls the appropriate routine if dynamic OW levels are used.
;===============================================================================
macro lda_13BF()
if !dynamic_ow_levels
    jsr shared_get_new_13BF
else ; if not(!dynamic_ow_levels)
    lda $13BF|!addr
endif ; !dynamic_ow_levels
endmacro

;===============================================================================
; Functions for (H)DMA address conversion
;===============================================================================
function dma(addr,ch)     = ((addr)+((ch)*$10))
function window_dma(addr) = dma(addr,!window_channel)
function upload_dma(addr) = dma(addr,!upload_channel)

;===============================================================================
; Utility functions for tilemap and stripe image management.
;===============================================================================
function xb(x)                = (((x)&$FF)<<8)|(((x)>>8)&$FF)
function l3_prop(pal,page)    = ($20|(((pal)&7)<<2)|((page)&1))
function l3_tile(tile,pal)    = ((tile)|((pal)<<8))
function str_header1(x,y)     = xb($5000|((y)<<5)|(x))
function str_header2(len,rle) = xb((((rle)&1)<<14)|(len))

;===============================================================================
; Utility functions for VRAM and graphics.
;===============================================================================
function vram_addr(offset) = (!sprite_vram+(offset*$10))
function gfx_size(num)     = (num*$20)

;===============================================================================
; Routine to get the prompt type for the current level.
;===============================================================================
get_prompt_type:
    ; If in title screen, override the normal settings.
    lda $0100|!addr : cmp #$07 : bne .level

.title:
if !title_death_behavior < 2
    lda.b #!retry_type_vanilla
elseif !title_death_behavior == 2
    lda.b #!retry_type_instant_death_sfx
else ; if not(!title_death_behavior < 2 && !title_death_behavior == 2)
    lda.b #!retry_type_instant_death_song
endif ; !title_death_behavior < 2
    rts

.level:
    ; If the override address is set, skip the rest.
    lda !ram_prompt_override : bne .not_default

    ; Otherwise, if the effect for this level is set, skip the default.
    jsr get_effect_value
    cmp #$00 : bne .not_default

    ; Otheriwse, use the default value.
    lda.b #!default_prompt_type+1

.not_default:
    rts

;===============================================================================
; Get translevel number the player is standing on the overworld.
;===============================================================================
get_translevel:
    lda $0109|!addr : beq .no_intro
    lda #$00 : sta $13BF|!addr
    rts
.no_intro:
    ldy $0DD6|!addr
    lda.w !ow_x_pos,y : lsr #4 : sta $00
    lda.w !ow_y_pos,y : and #$F0 : tsb $00
    lda.w !ow_y_pos+1,y : asl : sta $01
    lda.w !ow_x_pos+1,y : and #$01 : ora $01
    ldy $0DB3|!addr
    ldx.w !ow_submap,y : beq +
    clc : adc #$04
+   sta $01
    rep #$10
    ldx $00
    lda !7ED000,x : sta $13BF|!addr
    sep #$10
if !dynamic_ow_levels
    jmp get_new_13BF_no_intro
else ; not(!dynamic_ow_levels)
    rts
endif ; !dynamic_ow_levels

;===============================================================================
; Get correct $13BF value for current level (for patches that change level
; number dynamically).
;===============================================================================
if !dynamic_ow_levels
get_new_13BF:
    lda $0109|!addr : beq .no_intro
    lda #$00
    rts
.no_intro:
    phb
    lda #$05 : pha : plb
    tya
    jsl $05DCDC|!bank
    plb
    lda $0E
    cpy #$00 : beq +
    clc : adc #$24
+   rts
endif ; !dynamic_ow_levels

;===============================================================================
; Routine to save the current level's custom checkpoint value and set the midway
; flag.
;===============================================================================
hard_save:
    ; Filter title screen, etc.
    lda $0109|!addr : beq .no_intro
    cmp.b #!intro_level+$24 : beq .no_intro
    rts

.no_intro:
    phx

    ; We won't rely on $13CE anymore, so set the midway flag in $1EA2.
    %lda_13BF() : tax
    lda $1EA2|!addr,x : ora #$40 : sta $1EA2|!addr,x

    ; Set the level's custom checkpoint.
    rep #$30
    txa : and #$00FF : asl : tax
    lda !ram_respawn : sta !ram_checkpoint,x
    sep #$30

    plx
if !save_on_checkpoint
    jmp save_game
else ; if not(!save_on_checkpoint)
    rts
endif ; !save_on_checkpoint

;===============================================================================
; Routine to remove the current level's checkpoint.
; Note: $13CE isn't cleared because it's also used in the OW loading routine.
;===============================================================================
reset_checkpoint:
    phx
    phy
    %lda_13BF() : tay
    rep #$30
    and #$00FF : asl : tax
    lsr : cmp #$0025 : bcc +
    clc : adc #$00DC
+   sta !ram_checkpoint,x
    sta !ram_respawn
    sep #$30
    lda $1EA2|!addr,y : and #~$40 : sta $1EA2|!addr,y
    ply
    plx
    rts

;===============================================================================
; Routine to save the game.
;===============================================================================
save_game:
    phx
    phy

if !ow_flags_sram_buffer != $1EA2|!addr
    ; Set up vanilla SRAM buffer if needed.
    phb
    rep #$30
    ldx.w #$1EA2|!addr
    ldy.w #!ow_flags_sram_buffer
    lda.w #$008C
    mvn $00,$00
    sep #$30
    plb
endif

    ; Save to SRAM/BW-RAM.
    jsl $009BC9|!bank

    ply
    plx
    rts

;===============================================================================
; Routine to check if the current save file is empty
; Output: Carry set = save file empty
;         Carry clear = save file not empty
;===============================================================================
is_save_file_empty:
    php
    sep #$30
    ldx $010A|!addr
    phb
    ; Can't use %jsl_to_rts_db because plb clobbers the Z flag
    lda.b #$00|!bank8 : pha : plb
    %jsl_to_rts($009DB5)
    bne .empty
.not_empty:
    plb
    plp
    clc
    rts
.empty:
    plb
    plp
    sec
    rts

;===============================================================================
; Routines to reset and save the dcsave buffers.
;===============================================================================
dcsave:
.init:
    ; Return if dcsave isn't installed.
    lda.l !rom_dcsave_byte : cmp #$5C : bne .return

    ; Load the address to the dcsave init wrapper routine.
    rep #$20
    lda.l !rom_dcsave_init_address : clc : adc #$0011 : sta $0D
    sep #$20
    lda.l !rom_dcsave_init_address+2 : sta $0F

    ; Call the dcsave routine.
if !sa1
    %invoke_sa1(.jml)
else ; if not(!sa1)
    jsl .jml
endif ; !sa1
    rts

.midpoint:
    ; Return if dcsave isn't installed.
    lda.l !rom_dcsave_byte : cmp #$5C : bne .return

    ; Only save if !Midpoint = 1.
    lda.l !rom_dcsave_midpoint_byte : cmp #$22 : bne .return

    ; Load the address to the dcsave save buffer routine.
    rep #$20
    lda.l !rom_dcsave_midpoint_address : sta $0D
    sep #$20
    lda.l !rom_dcsave_midpoint_address+2 : sta $0F

    ; Call the dcsave routine.
    jsl .jml

.return:
    rts

.jml:
    jml [$000D|!dp]

;===============================================================================
; Routine to get the checkpoint value for the current sublevel. Returns the
; value in A (8 bit). You should use cmp #$00 to check for 0 after calling this.
; X, Y and P are preserved.
;===============================================================================
get_checkpoint_value:
    phx
    php
    rep #$10
    ldx $010B|!addr
    lda.l tables_checkpoint_effect,x
    and #$0F
    plp
    plx
    rts

;===============================================================================
; Routine to get the effect value for the current sublevel. Returns the value in
; A (8 bit). You should use cmp #$00 to check for 0 after calling this.
; X, Y and P are preserved.
;===============================================================================
get_effect_value:
    phx
    php
    rep #$10
    ldx $010B|!addr
    lda.l tables_checkpoint_effect,x
    lsr #4
    and #$0F
    plp
    plx
    rts

;===============================================================================
; Routine to get the RNG reset value for the current sublevel. Returns the value
; in A (8 bit). You should use cmp #$00 to check for 0 after calling this.
; X, Y and P are preserved.
;===============================================================================
get_reset_rng_value:
    phx
    php
    rep #$10
    ldx $010B|!addr
    lda.l tables_reset_rng,x
    plp
    plx
    rts

;===============================================================================
; Routine to get the index and mask to a bitwise sublevel table. Returns the
; index to the table in X, and the mask in A (8 bit).
; A/X/Y should be in 8-bit mode when calling this. Y is preserved.
;===============================================================================
get_bitwise_mask:
    lda $010B|!addr : and #$07 : tax
    lda.l .mask_table,x : pha
    rep #$20
    lda $010B|!addr : lsr #3 : tax
    sep #$20
    pla
    rts

.mask_table:
    db $80,$40,$20,$10,$08,$04,$02,$01

;===============================================================================
; Routine to get current screen number in X.
; If Lunar Magic 3.0+ is used, it may overwrite Y.
;===============================================================================
get_screen_number:
    lda.l !rom_lm_version : cmp #$33 : bcc .no_lm3
    lda.l !rom_lm_get_screen_routine : cmp #$FF : beq .no_lm3
.lm3:
    jsl !rom_lm_get_screen_routine
    rts
.no_lm3:
    ldx $95
    lda $5B : lsr : bcc .return
    ldx $97
.return:
    rts

;===============================================================================
; Routine that returns the intro sublevel in A.
; Output: A 16 bit, intro sublevel in A.
;===============================================================================
get_intro_sublevel:
    rep #$20
    lda.l !rom_initial_submap : and #$00FF : beq .normal
    lda.l !rom_sprite_19_fix_byte : cmp #$EAEA : bne .normal
.modified:
    lda.w #!intro_level|$0100
    rts
.normal:
    lda.w #!intro_level
    rts

;===============================================================================
; Routine that updates the OAM table at $0400 using the decompressed mirror at
; $0420. Useful if you need to draw sprites during fadein.
;===============================================================================
update_0400:
    %jsl_to_rts_db($008494)
    rts

;===============================================================================
; Routine to check if a level entrance destination would trigger a room
; checkpoint in the current sublevel.
; Input: A = entrance destination value high byte
; Output: Carry = Set (Yes) / Reset (No)
;===============================================================================
is_destination_a_checkpoint:
    ; Save A for later
    xba

    ; If room checkpoints are disabled, return no
    lda !ram_midways_override : bmi .no

    ; Get the current sublevel checkpoint setting.
    jsr shared_get_checkpoint_value
    and.b #~(!checkpoint_type_midway_bar|!checkpoint_type_temporary_flag)

    ; If room checkpoint is disabled, return no.
    beq .no

    ; If all entrances should count, return yes.
    cmp.b #!checkpoint_type_all_entrance : beq .yes

    ; Check which type of entrance should count.
    cmp.b #!checkpoint_type_main_midway_entrance : bne .check_secondary

.check_main_midway:
    ; Return yes if it's not a secondary entrance.
    xba : and #$02 : beq .yes
    bra .no

.check_secondary:
    ; Return yes if it's a secondary entrance.
    xba : and #$02 : beq .no

.yes:
    sec
    rts

.no:
    clc
    rts

;===============================================================================
; Routine to set the Retry checkpoints accordingly with the initial OW flags
; (i.e. the "Midway point obtained" flag)
;===============================================================================
set_checkpoints_from_initial_ow_flags:
    php
    sep #$30
    ldy.b #!ow_levels_count-1
.loop:
    ; Skip if the "Midway point obtained" flag is not set
    lda.w !ow_flags_sram_buffer,y : and #$40 : beq ..next
    ; X = 2*Y (for checkpoint table)
    rep #$30
    tya : and #$00FF : asl : tax
    sep #$20
    ; Skip if the checkpoint is for a secondary exit (just to be sure)
    lda !ram_checkpoint+1,x : bit #$02 : bne ..next
    ; Set the midway bit in the checkpoint
    ora #$08 : sta !ram_checkpoint+1,x
    sep #$10
..next:
    dey : bpl .loop
    plp
    rts

;===============================================================================
; Helper routine to reset the RNG state.
;===============================================================================
reset_rng:
    rep #$20
    stz $148B|!addr
    stz $148D|!addr
    sep #$20
    rts

;===============================================================================
; idk what to call it
; It checks if the prompt is active in the level and it was activated
; Carry clear: no
; Carry set: yes
;===============================================================================
is_prompt_deployed:
    jsr shared_get_prompt_type
    cmp.b #!retry_type_prompt_max+1 : bcs .no
    lda !ram_is_respawning : bne .yes
    lda !ram_prompt_phase : beq .no
.yes:
    sec
    rts
.no:
    clc
    rts

;===============================================================================
; Returns the amount of global songs inserted with AddmusicK in A.
; If AddmusicK is not inserted, it returns 0.
; It may count more songs than actually present if someone omits the first local
; song(s) from the AddmusicK list, but it's not an issue for what we're using
; this for.
;===============================================================================
get_amk_global_song_count:
    lda.l !rom_amk_byte : cmp #$5C : beq .amk
.no_amk:
    sep #$20
    lda #$00
    rts
.amk:
    ; Get pointer to the AMK header data
    lda.l !rom_amk_byte+3 : sta $02
    rep #$20
    lda.l !rom_amk_byte+1 : sec : sbc.w #!amk_header_size : sta $00
    ldy #$00

    ; Check if the @AMK is present where we expect
    lda [$00],y : cmp.w #!amk_header_string : bne .no_amk
    iny #2
    lda [$00],y : cmp.w #!amk_header_string>>16 : bne .no_amk

    ; Set data bank to the music pointers table bank
    phb
    ldy.b #!amk_music_ptrs_offset+1
    lda [$00],y : pha : plb : plb

    ; Get pointer to the music pointers table
    dey
    lda [$00],y : sta $00

    ; Count all the starting NULL pointers
    ; (the first is for song 0 that does not count towards the total)
    rep #$30
    ldy #$0003
    ldx #$0000
-   lda ($00),y
    iny
    ora ($00),y : bne +
    inx
    iny #2
    bra -
+   
    plb
    sep #$30
    txa
    rts
