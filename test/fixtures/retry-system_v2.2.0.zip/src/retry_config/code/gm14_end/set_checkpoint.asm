;=====================================
; set_checkpoint routine
;=====================================
set_checkpoint:
    ; If the reset value is not set, set the checkpoint.
    lda !ram_set_checkpoint : cmp #$80 : bne .set

.reset:
    ; Otherwise, reset the checkpoint.
    jsr shared_reset_checkpoint
    stz $13CE|!addr

if !save_on_checkpoint
    jsr shared_save_game
endif ; !save_on_checkpoint

    bra .backup_music

.set:
    ; Save individual dcsave buffers.
    ; Needed because we skip over $00F2DD, where the routine is called.
    jsr shared_dcsave_midpoint
    
    ; Set midway flag, just to be safe.
    lda #$01 : sta $13CE|!addr
    
    ; Check if it's a normal or custom midway.
    lda !ram_set_checkpoint+1 : cmp #$FF : bne ..custom_destination

..normal_midway:
    ; If it's the intro level, skip.
    lda $0109|!addr : beq ...no_intro
    cmp.b #!intro_level+$24 : bne .return

...no_intro:
    jsr shared_get_checkpoint_value
    
    ; Save temporary flag for later.
    bit.b #!checkpoint_type_temporary_flag : php
    
    ; Check if this midway sets the midway entrance for the sublevel or the main level.
    and.b #!checkpoint_type_midway_bar : bne ...sub_midway

...main_midway:
    jsr calc_entrance
    bra ...shared

...sub_midway:
    jsr calc_entrance_2

...shared:
    ; If the temporary flag is set, don't save the checkpoint.
    plp : bne .backup_music
    bra .save_and_return

..custom_destination:
    ; Set the checkpoint destination.
    rep #$20
    lda !ram_set_checkpoint : sta !ram_respawn
    sep #$20

    ; If we're in the Yoshi Wings level, set the flag if applicable.
    ldy $1B95|!addr : beq .save_and_return
    xba : bit #$0A : bne .save_and_return
    ora #$80 : sta !ram_respawn+1

.save_and_return:
    ; Save the midway entrance as a checkpoint.
    jsr shared_hard_save

.backup_music:
    ; If the midway is a secondary entrance or not in the same sublevel
    ; force to reload the samples to be safe.
    ldy #$FF
    rep #$20
    lda !ram_respawn
    bit #$0200 : bne +
    and #$01FF : cmp $010B|!addr : bne +
    ; Otherwise, backup the music to play.
    ldy $0DDA|!addr
+   sep #$20
    tya : sta !ram_music_to_play

.return:
    ; Reset the set_checkpoint address.
    lda #$FF : sta !ram_set_checkpoint : sta !ram_set_checkpoint+1
    rts

;=====================================
; calc_entrance routine
;=====================================
calc_entrance:
    ; If it's not the intro level, skip.
    %lda_13BF() : tax : bne .no_intro

    ; Set intro sublevel number as respawn point.
    jsr shared_get_intro_sublevel
    sta !ram_respawn
    sep #$20
    bra .check_midway

.no_intro:
    ; Convert $13BF value to sublevel number.
    rep #$20
    and #$00FF : cmp.w #$0025 : bcc ..store_entrance
    clc : adc.w #$00DC
..store_entrance:
    sta !ram_respawn

.check_midway:
    ; If the midway flag is not set, return.
    lda $1EA2|!addr,x : and.w #$0040
    sep #$20
    bne ..midway
    lda $13CE|!addr : beq .return

..midway:
    ; Set the midway flag in the respawn entrance.
    lda !ram_respawn+1 : ora #$08 : sta !ram_respawn+1

.return:
    rts

.2:
    ; Get $13BF value in X.
    %lda_13BF() : tax

    ; Set current sublevel number as the respawn point.
    rep #$20
    lda $010B|!addr
    bra .no_intro_store_entrance
