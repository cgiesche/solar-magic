;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Brutal Bill (aka "Brutal Mario"-style Homing Bullet Bill)
;; by Sonikku
;; 
;; This is a recreation of the Homing Bullet Bill originally created by Carol and seen in many hacks of the era.
;; The bullet boosts toward the player (usually in a fast arc upwards or downwards) before slowing down for a moment.
;; Then, it boosts again.
;; 
;; 
;; Some history:
;; The sprite originally was never officially released by Carol to my knowledge.
;; It was given to a handful of people, usually in the Japanese SMW hacking scene.
;; It saw an "unofficial" release with the leak of the Brutal Mario ASM repository, "data.zip".
;; 
;; I do not support using the contents of the leaked repository.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Settings

!XSpeed =		$30		; X speed sprite boosts toward the player at.

!SFX_Bullet =		$09		; \ SFX to play when boosting at the player. Set to $00 for no SFX.
!Bank_Bullet =		$1DFC		; /

!ShowSmoke =		1		; Show a smoke effect when the bullet boosts toward the player?

!DiffDeadPal =		$02		; If any value other than "-1", the sprite will use that palette row while dead.
					; (i.e. $00 for palette 8, $02 for palette 9, etc.)

!PaletteCycle =		2		; If 0, do not cycle through palettes.
					; If 1+, cycle through palettes from "PaletteCycle" table below. Higher values make it cycle slower.

!DisableBehind =	0		; If set to 1, sprite never goes behind objects when !163E,x is set.
					; !163E,x is intended to be set by a shooter, so it can appear behind the blaster tile for a brief moment.
					; If you're using certain HDMA effects, you may want to set this to "1".

PaletteCycle:				; Palettes to cycle through.
	db $08,$04
.end

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Info for ASMers:
;; - !C2,x   = Sprite's current state. If set to #$02, it immediately initializes a boost toward the player.
;; - !163E,x = Timer to appear behind objects, if "!DisableBehind" is 0.
;; - !1540,x = Timer to prevent actually boosting at the player. Intended use is for the brief moment it exits a blaster.
;; - !1594,x = Number of times the sprite boosts back at the player, minus one. If zero, sprite will permanently chase until defeated.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

macro PlaySFX(num,bank)
	if <num> != $00
		LDA.b #<num>
		STA <bank>|!addr
	endif
endmacro

print "INIT ",pc
Init:	PHB
	PHK
	PLB
	LDA !extra_byte_1,x
	STA !1594,x
	JSR InitializeBoost
	PLB
	RTL

print "MAIN ",pc
	PHB
	PHK
	PLB
if not(!DisableBehind)
	LDA $64
	PHA
	LDA !163E,x
	BEQ +
	LDA #$10
	STA $64
+	JSR SubGFX
	PLA
	STA $64
else
	JSR SubGFX
endif
	JSR Main
	PLB
	RTL

Main:	LDA #$00
	%SubOffScreen()
	LDA !14C8,x
	CMP #$08
	BNE .Return
	LDA $9D
	BEQ .Alive
.Return	RTS

.Alive	JSL $01801A|!bank
	JSL $018022|!bank

if !PaletteCycle != 0
	INC !1570,x
	LDA !1570,x
	if !PaletteCycle > 1
	LSR #(!PaletteCycle-1)
	endif
	CMP.b #(PaletteCycle_end-PaletteCycle)
	BCC +
	LDA #$00
	STA !1570,x
+	TAY
	LDA PaletteCycle,y
	STA !15F6,x
endif

	LDA !C2,x
	ASL
	TAX
	JSR (.ptr,x)

;; run collision w/ mario and sprites after main code
;; this prevents issues where the sprite fails to fall straight down as expected when dying
	JSL $01A7DC|!bank
	JSL $018032|!bank
	RTS

.ptr	dw x00_Boosting		; 
	dw x01_SlowingDown	; 
	dw InitializeBoost	; 

!Temp_Homing_X_Lo	= !1504
!Temp_Homing_X_Hi	= !1510
!Temp_Homing_Y_Lo	= !151C
!Temp_Homing_Y_Hi	= !1528

x00_Boosting:
	LDX $15E9|!addr

;; set x speed
	LDY !157C,x
	LDA .X_Speed,y
	STA !B6,x

;; return if !1540,x set (usually only set on-spawn from a shooter)
	LDA !1540,x
	BNE .Return
;; process y speed
	JSR GetHomingCoords_Y
	LDY #$00
	LDA $0B
	BPL +
	INY
+	JSR Vert_Speed

	JSR GetHomingCoords_X
;; begin slowing down once sprite passes the locked-on X position
	REP #$20
	LDY #$00
	LDA $08
	BPL +
	INY
+	SEP #$20
	TYA
	CMP !157C,x
	BNE .Return
	LDA #$01
	STA !C2,x
.Return	RTS

.X_Speed	db !XSpeed,-!XSpeed

x01_SlowingDown:
	LDX $15E9|!addr
;; reduce y speed
	LDA !AA,x
	BEQ .ProcessXSpeed
	BPL +
	INC #2
+	DEC
	STA !AA,x
	INY
.ProcessXSpeed
	LDY #$00
	LDA !1594,x
	BEQ .DontGiveUp
	CMP !1534,x
	BCC .Return
.DontGiveUp
;; reduce x speed
	LDA !B6,x
	BEQ .TryResetState
	BPL +
	INC #2
+	DEC
	STA !B6,x
.Return	RTS
.TryResetState
;; if X and Y speed are zero, we re-boost
	CPY #$00
	BNE .Return
if !ShowSmoke
	JSR InitializeBoost
	LDA !15A0,x
    ORA !186C,x
	BNE .NoSmoke
	LDA #$08
	CPY #$00
	BNE +
	LDA #$F8
+	STA $00
	STZ $01
	LDA #$1A
	STA $02
	LDA #$01
	%SpawnSmoke()
.NoSmoke
	RTS
endif
InitializeBoost:
	LDX $15E9|!addr
	LDA !1594,x
	BEQ +
	INC !1534,x
+	LDA $94
	STA !Temp_Homing_X_Lo,x
	LDA $95
	STA !Temp_Homing_X_Hi,x
	LDA $96
	CLC
	ADC #$10
	STA !Temp_Homing_Y_Lo,x
	LDA $97
	ADC #$00
	STA !Temp_Homing_Y_Hi,x
	%SubHorzPos()
	TYA
	STA !157C,x
	%PlaySFX(!SFX_Bullet,!Bank_Bullet)
	STZ !C2,x
	RTS

Vert_Speed:
	REP #$20
	LDA $0A
	CPY #$00
	BEQ +
	EOR #$FFFF
	INC
+	CMP #$007F
	BCC .SetYSpeed
	LDA #$007F
.SetYSpeed
	CPY #$00
	BNE +
	EOR #$FFFF
	INC
+	SEP #$20
	STA !AA,x
	RTS

GetHomingCoords:
.X	LDA !E4,x
	SEC
	SBC !Temp_Homing_X_Lo,x
	STA $08
	LDA !14E0,x
	SBC !Temp_Homing_X_Hi,x
	STA $09
	RTS
.Y	LDA !D8,x
	SEC
	SBC !Temp_Homing_Y_Lo,x
	STA $0A
	LDA !14D4,x
	SBC !Temp_Homing_Y_Hi,x
	STA $0B
	RTS

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; GFX Routine
!0300	= $0300|!addr
!0301	= $0301|!addr
!0302	= $0302|!addr
!0303	= $0303|!addr
!0460	= $0460|!addr

SubGFX:	LDX $15E9|!addr
	%GetDrawInfo()
	LDA #$FF
	STA $0F

	LDA !157C,x
	STA $02

	LDA !166E,x
	AND #$01
	ORA !15F6,x
	AND #$0F
	STA $04

	STZ $03
	LDA !14C8,x
	CMP #$02
	BNE +
	STA $03
if !DiffDeadPal != -1
	LDA !166E,x
	AND #$01
	ORA.b #!DiffDeadPal
	AND #$0F
	STA $04
endif
+
	LDA $00
	STA !0300,y

	LDA $01
	STA !0301,y

	LDA #$A6
	STA !0302,y

	LDA $04
	PHX
	LDX $02
	BNE +
	EOR #$40
+	LDX $03
	BEQ +
	EOR #$80
+	ORA $64
	PLX
	STA !0303,y

	LDY #$02
	LDA #$00
	%FinishOAMWrite()
	RTS