; The extra bit determines whether the spawned sprite will have its extra byte activated or not.
; modified from MarioFanGamer's Customisable Shooter ( https://smwc.me/s/16174 )

!Sprite = $18		; Sprite number of BrutalBill.json

!SoundEffect = $09
!SFXPort = $1DFC

; 0 means no, 1 means yes
!GenerateSmoke = 1
!ShootIfNear = SEC ; This time, CLC means yes and SEC means no

print "INIT ",pc
print "MAIN ",pc
PHB : PHK : PLB
	JSR Shooter
PLB
RTL

Return:
RTS

%define_sprite_table("shooter_extra_byte_1",$7FAC00,$60F1)
%define_sprite_table("shooter_extra_byte_2",$7FAC08,$6030)
%define_sprite_table("shooter_extra_byte_3",$7FAC10,$6038)

Shooter:
	LDA !shooter_extra_byte_2,x : !ShootIfNear	; Set the timer and don't ignore Mario
	%ShooterMain()
	BCS Return

	LDA #!SoundEffect	; Play sound effect
	STA !SFXPort|!Base2	;

	LDA #$00
	STA $0F
	LDA $1783|!Base2,x
	AND #$40
	BEQ +
	LDA #$04
	STA $0F
+	PHX
	TYX
	LDA #!Sprite
	STA !7FAB9E,x
	JSL $07F7D2|!BankB
	JSL $0187A7|!BankB
	LDA #$88
	ORA $0F
	STA !7FAB10,x
	PLX

	LDA $178B|!Base2,x
	SEC : SBC #$01
	STA.w !D8,y
	LDA $1793|!Base2,x
	SBC #$00
	STA !14D4,y
	LDA $179B|!Base2,x
	STA.w !E4,y
	LDA $17A3|!Base2,x
	STA !14E0,y

	LDA #$01
	STA !14C8,y

;; for ASMers, this is the "new" code.
	LDA !shooter_extra_byte_1,x
	PHX
	TYX
	STA !extra_byte_1,x
	LDA #$08
	STA !163E,x
	STA !1540,x
	PLX
;;

if !GenerateSmoke
	PHX
	TYX
	%SubHorzPos()
	LDA SmokeOffset,y
	STA $00
	STZ $01
	LDA #$1B
	STA $02
	LDA #$01
	%SpawnSmoke()
	PLX
endif
RTS

SmokeOffset:
db $0C,$F4
