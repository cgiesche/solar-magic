Rock climbing blocks, by GreenHammerBro.

These 2 blocks allows the player to climb up walls by jumping off of them. Not
to be confused by wall jump blocks, these act like mini ledges. To use them
you must:

-Not be crouching.
-holding left or right towards the direction of the wall.
-Must be touching the wall (layer hitbox wise). A single pixel away or more
 does not count.*

*Note that this may not work if you change the width of the
 player's layer 1 hitbox, you need to change the number after the ORA/SBC
 (labeled "number of pixels from center of block" so that the block works with
 the new hitbox). Make sure the value you are using is less than #$10, else it
 won't work.

Where xx is how far to the right from center of the block in order to stand on
the block.

Keep in mind that if you press the opposite direction at the same time you
jump, you'll fall off instead of jumping due to the order the game runs the
routine.

I have included a block list, map16, and graphic to set it up. Make sure the
graphic file is used as "BG2" (the 2nd dropdown list on the right column) if
you are using the map16 file if you want the graphics to sync/match.
------------------------------------------------------------------------------
Version history (M/D/Y, finally ordered from recent to old):

1/25/2026 (by yoshifanatic)
-Made this SA-1 compatible.

5/31/2016
-Was removed for the following reasons:
 -The 3 checks of "should mario be standing on a ledge" order is not properly
  prioritized. The position check that is being first takes the longest and
  therefore, makes the game take longer to process than checking the
  crouching and button checks.
 -You don't need to go into 16-bit x position checking since there are no bugs
  with the screen boundaries in 8-bit.
 -On left wall edge, you don't need to CLC : ADC #$0002 if you can do ORA
  #$0002 (Both of them sets bit 1). This is because the code adds from a fixed
  nibble (bits 0-3), which is zero.
 -The code to make the block act like a ledge uses LDA #$00 : STA $1693, which
  can be shorten to STZ $1693.

5/30/2016
-First release
