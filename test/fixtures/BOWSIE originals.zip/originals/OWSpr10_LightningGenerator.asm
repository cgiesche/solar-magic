
; Overworld sprite 10 - Lightning Generator by yoshifanatic
; This will randomly trigger a flashing lightning animation on color 00, similar to how the Valley of Bowser submap does in the original SMW.
; If not using Overworld Revolution, place it wherever on the map to have it run.
; If using Overworld Revolution, spawn it through a silent event script so it loads regardless of the camera position.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_Overworld_UseLightningPaletteFromROM = 0			; Set this to 1 to mimic the similarly named Lunar Magic setting.

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_ProcessWhenOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
main:
if !bowsie_owrev == 1
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BEQ.b +
	RTL

+:
endif
	SEP.b #$20
	LDY.w !RAM_SMW_Palettes_LightningFlashColorIndex
	BNE.b CODE_04F73B
	LDA.b !RAM_SMW_Counter_LocalFrames
	LSR
	BCC.b CODE_04F76E
	DEC.w !RAM_SMW_Timer_WaitBeforeNextLightningFlash
	BNE.b CODE_04F76E
	TAY
	PHB
	PEA.w DATA_04F6F8>>8
	PLB
	PLB
	LDA.w DATA_04F708,y
	AND.b #$07
	TAX
	LDA.w DATA_04F6F8,x
	STA.w !RAM_SMW_Timer_WaitBeforeNextLightningFlash
	LDY.w DATA_04F700,x
	STY.w !RAM_SMW_Palettes_LightningFlashColorIndex
	PLB
	LDA.b #$08
	STA.w !RAM_SMW_Timer_LightningFrameDuration
	LDA.b #!Define_SMW_Sound1DFC_Thunder
	STA.w !RAM_SMW_IO_SoundCh3
CODE_04F73B:
	DEC.w !RAM_SMW_Timer_LightningFrameDuration
	BPL.b CODE_04F748
	DEC.w !RAM_SMW_Palettes_LightningFlashColorIndex
	LDA.b #$04
	STA.w !RAM_SMW_Timer_LightningFrameDuration
CODE_04F748:
	TYA
	ASL
	TAY
	LDX.w !RAM_SMW_Palettes_DynamicPaletteUploadIndex
	LDA.b #$02
	STA.w !RAM_SMW_Palettes_DynamicPaletteBytesToUpload,x
	LDA.b #$47
	STA.w !RAM_SMW_Palettes_DynamicPaletteCGRAMAddress,x
if !Define_SMW_Overworld_UseLightningPaletteFromROM == 0
	LDA.w SMW_PaletteMirror[$28].LowByte,y
	STA.w !RAM_SMW_Palettes_DynamicPaletteColors,x
	LDA.w SMW_PaletteMirror[$28].HighByte,y
else
	LDA.l SMW_GlobalPalettes_BowserLightningFlash,x
	STA.w !RAM_SMW_Palettes_DynamicPaletteColors,x
	LDA.l SMW_GlobalPalettes_BowserLightningFlash+$01,x
endif
	STA.w !RAM_SMW_Palettes_DynamicPaletteColors+$01,x
	STZ.w !RAM_SMW_Palettes_DynamicPaletteColors+$02,x
	TXA
	CLC
	ADC.b #$04
	STA.w !RAM_SMW_Palettes_DynamicPaletteUploadIndex
CODE_04F76E:
	LDX.w !RAM_SMW_Sprites_CurrentlyProcessedOverworldSprite
	REP.b #$20
	RTL
