
; Overworld sprite 02 - Blue Bird by yoshifanatic
; The unused blue bird sprite from the original SMW.
; There are no restrictions on placement compared to the original game. Place as many as you desire.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_OWSpr02_BlueBird_Palette = $06
!Define_SMW_OWSpr02_BlueBird_BodyTile = $004C
!Define_SMW_OWSpr02_BlueBird_WingTile1 = $004E
!Define_SMW_OWSpr02_BlueBird_WingTile2 = $004F
!Define_SMW_OWSpr02_BlueBird_WingTile3 = $005E

!RAM_SMW_OWSpr02_BlueBird_AnimationFrameCounter #= !ow_sprite_misc_1

Acceleration:
	dw $0010,$FFF0

MaxXSpeed:
	dw $0100,$FF00

Prop:
	dw (!Define_SMW_OWSpr02_BlueBird_Palette|$30)<<8,(!Define_SMW_OWSpr02_BlueBird_Palette|$70)<<8

WingXDisp:
	dw $0008,$0007,$0004,$0007
	dw $0000,$0001,$0004,$0001

WingYDisp:
	dw $0001,$0007,$0009,$0007
	dw $0001,$0007,$0009,$0007

WingTiles:
	dw !Define_SMW_OWSpr02_BlueBird_WingTile1,!Define_SMW_OWSpr02_BlueBird_WingTile2
	dw !Define_SMW_OWSpr02_BlueBird_WingTile3,!Define_SMW_OWSpr02_BlueBird_WingTile2
	dw !Define_SMW_OWSpr02_BlueBird_WingTile1,!Define_SMW_OWSpr02_BlueBird_WingTile2
	dw !Define_SMW_OWSpr02_BlueBird_WingTile3,!Define_SMW_OWSpr02_BlueBird_WingTile2

EraseSprite:
	%erase_sprite()
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_ProcessWhenOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	SEP.b #$20
	JSL.l SMW_GetRand_Main
	REP.b #$20
	LDA.w !RAM_SMW_Misc_RandomByte1
	STA.w !RAM_SMW_OWSpr02_BlueBird_AnimationFrameCounter,x
	LDA.w #$0040
	STA.w !RAM_SMW_OWSpr_ZPosLo,x
main:
if !bowsie_owrev == 1
	%sub_offscreen()
	BCS.b EraseSprite
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BEQ.b +
	JMP.w GFXRt

+:
endif
	INC.w !RAM_SMW_OWSpr02_BlueBird_AnimationFrameCounter,x
	%distance()
	LDY.b #$00
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	BMI.b +
	LDY.b #$02
+:
	LDA.w !RAM_SMW_OWSpr_XSpeed,x
	CLC
	ADC.w Acceleration,y
	CMP.w MaxXSpeed,y
	BEQ.b +
	STA.w !RAM_SMW_OWSpr_XSpeed,x
+:
	LDY.w !RAM_SMW_Player_CurrentCharacterX4Lo
	LDA.w !RAM_SMW_Overworld_MarioYPosLo,y
	CLC
	ADC.w #$000E
	STA.w !RAM_SMW_OWSpr_YPosLo,x
	%sub_update_x_pos()
GFXRt:
	LDY.b #$00
	LDA.w !RAM_SMW_OWSpr_XSpeed,x
	STA.b !RAM_SMW_Misc_ScratchRAM0C
	BMI.b +
	LDY.b #$02
+:
	LDA.w Prop,y
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w !RAM_SMW_OWSpr02_BlueBird_AnimationFrameCounter,x
	LSR
	LSR
	AND.w #$0006
	LDY.b !RAM_SMW_Misc_ScratchRAM0D
	BMI.b +
	CLC
	ADC.w #$0008
+:
	STA.b !RAM_SMW_Misc_ScratchRAM8A
	LDA.w #$0001
	SEC
	%get_draw_info()
	BCC.b .SpriteOnScreen
	JMP.w .SpriteOffScreen

.SpriteOnScreen:
	%maxtile_set_databank()
	SEP.b #$20
	%draw_vanilla_shadow()
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0000
	LDA.w #$0001
	%finish_oam_write()
	LDA.w #$0001
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	LDX.b !RAM_SMW_Misc_ScratchRAM8A
	SEP.b #$20
-:
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	STA.w oam_buffer[$01].x_pos,y
	CLC
	ADC.l WingXDisp,x
	STA.w oam_buffer[$00].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	STA.w oam_buffer[$01].y_pos,y
	CLC
	ADC.l WingYDisp,x
	STA.w oam_buffer[$00].y_pos,y
	LDA.l WingTiles,x
	STA.w oam_buffer[$00].tile,y
	LDA.b #!Define_SMW_OWSpr02_BlueBird_BodyTile
	STA.w oam_buffer[$01].tile,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0F
	STA.w oam_buffer[$00].props,y
	STA.w oam_buffer[$01].props,y
    REP #$20
    %maxtile_get_tilesize_index()
    SEP #$20
	LDA.b #$00
	STA.w oam_tilesize_buffer[$00].tile_sx,y
	LDA.b #$02
	STA.w oam_tilesize_buffer[$01].tile_sx,y
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$FFFF
	LDA.w #$0001
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
