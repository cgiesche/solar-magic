
; Overworld sprite 0C - Flying Switch Block by yoshifanatic
; This will spawn a switch block that flies in one of 8 directions based on the 1st extra byte.
; While you can place this, it's better to spawn it within another sprite's code or through a script.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 1

!Define_SMW_OWSpr0C_FlyingSwitchBlock_Tile = $00E6

!RAM_SMW_OWSpr0C_FlyingSwitchBlock_FlyingDirection #= !RAM_SMW_OWSpr_ExtraByte1

InitialXSpeed:
	dw $0000,$FD80,$FD00,$FD80,$0000,$0280,$0300,$0280

InitialYSpeed:
	dw $FD00,$FD80,$0000,$0280,$0300,$0280,$0000,$FD80

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	LDA.w !RAM_SMW_OWSpr0C_FlyingSwitchBlock_FlyingDirection,x
	AND.w #$0007
	ASL
	TAY
	LDA.w InitialXSpeed,y
	STA.w !RAM_SMW_OWSpr_XSpeed,x
	LDA.w InitialYSpeed,y
	STA.w !RAM_SMW_OWSpr_YSpeed,x
	LDA.w #$0300
	STA.w !RAM_SMW_OWSpr_ZSpeed,x
	LDY.b #!Define_SMW_Sound1DFC_OverworldSwitchBlockEjection
	STY.w !RAM_SMW_IO_SoundCh3
main:
	%sub_offscreen()
	BCS.b EraseSprite
if !bowsie_owrev == 1
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BEQ.b +
	JMP.w GFXRt

+:
endif
	LDA.w !RAM_SMW_OWSpr_ZPosLo,x
	BPL.b +
EraseSprite:
	%erase_sprite()
	RTL

+:
	LDA.w !RAM_SMW_OWSpr_ZSpeed,x
	SEC
	SBC.w #$0010
	BPL.b +
	CMP.w #$FC00
	BCS.b +
	LDA.w #$FC00
+:
	STA.w !RAM_SMW_OWSpr_ZSpeed,x
	%sub_update_x_pos()
	%sub_update_y_pos()
	%sub_update_z_pos()
GFXRt:
	LDA.w !RAM_SMW_Misc_ColorOfPalaceSwitchPressed1
	AND.w #$00FF
	DEC
	ASL
	XBA
	ORA.w #$3000|!Define_SMW_OWSpr0C_FlyingSwitchBlock_Tile
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w #$0001
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	%draw_vanilla_shadow()
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0000
	LDA.w #$0001
	%finish_oam_write()
	LDA.w #$0000
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	STA.w oam_buffer[$00].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	STA.w oam_buffer[$00].y_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0E
	STA.w oam_buffer[$00].tile,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0F
	STA.w oam_buffer[$00].props,y
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0002
	LDA.w #$0000
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
