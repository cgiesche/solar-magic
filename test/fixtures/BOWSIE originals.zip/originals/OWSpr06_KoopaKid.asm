
; Overworld sprite 06 - Koopa Kid by yoshifanatic
; The unused koopa kid sprite.
; If not using Overworld Revolution, place it where you want it to spawn, then use the two extra bytes to specify the X/Y coordinates Mario needs to be to activate the koopa kid. You're still limited to three though.
; If you are using Overworld Revolution, then you can just spawn the koopa kid through a script at any time desired with script command 2E. Placing it directly will just cause it to run immediately. You can use as many as you want.

incsrc "OriginalSMWSpriteDefines.asm"

if !bowsie_owrev == 1
!extra = 0
; No extra bytes for Overworld Revolution.
else
!extra = 3
;Extra bytes: 00 00 00
; 1 = X grid aligned coordinate of Mario
; 2 = Y grid aligned coordinate of Mario
; 3 = Tile Teleport Index (should be 00-02)
endif

!Define_SMW_OWSpr06_KoopaKid_Palette = $02
!Define_SMW_OWSpr06_KoopaKid_Tile = $006A

!RAM_SMW_OWSpr06_KoopaKid_CurrentMovementState #= !ow_sprite_misc_1
!RAM_SMW_OWSpr06_KoopaKid_AnimationTimer #= !ow_sprite_misc_2
!RAM_SMW_OWSpr06_KoopaKid_IsActiveFlag #= !ow_sprite_misc_3
!RAM_SMW_OWSpr06_KoopaKid_InitialXPos #= !ow_sprite_misc_4
!RAM_SMW_OWSpr06_KoopaKid_StateTimer #= !ow_sprite_timer_1
!RAM_SMW_OWSpr06_KoopaKid_XYCoordToCheck #= !RAM_SMW_OWSpr_ExtraByte1
!RAM_SMW_OWSpr06_KoopaKid_WarpIndex #= !RAM_SMW_OWSpr_ExtraByte3

Prop:
	dw (!Define_SMW_OWSpr06_KoopaKid_Palette|$20)<<8,(!Define_SMW_OWSpr06_KoopaKid_Palette|$60)<<8

DATA_04FB94:
	dw $0002,$0008

DATA_04FB96:
	dw $0000,$000F

ResetKoopaKid:
	STZ.w !RAM_SMW_OWSpr06_KoopaKid_IsActiveFlag,x
	LDA.w #$FF00
	STA.w !RAM_SMW_OWSpr_XSpeed,x
	LDA.w !RAM_SMW_OWSpr06_KoopaKid_InitialXPos,x
	STA.w !RAM_SMW_OWSpr_XPosLo,x
	STZ.w !RAM_SMW_OWSpr_CurrentState,x
	RTS

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	LDA.w !RAM_SMW_OWSpr_XPosLo,x
	STA.w !RAM_SMW_OWSpr06_KoopaKid_InitialXPos,x
main:
if !bowsie_owrev == 1
	%sub_offscreen()
	BCS.b EraseSprite
endif
	LDA.w !RAM_SMW_OWSpr06_KoopaKid_IsActiveFlag,x
	BNE.b KoopaKidActive
if !bowsie_owrev == 1
else
	LDY.w !RAM_SMW_Player_CurrentCharacterX4Lo
	LDA.w !RAM_SMW_OWSpr06_KoopaKid_XYCoordToCheck,x
	SEP.b #$20
	CMP.w !RAM_SMW_Overworld_MarioGridAlignedXPosLo,y
	BNE.b Return
	XBA
	CMP.w !RAM_SMW_Overworld_MarioGridAlignedYPosLo,y
	BNE.b Return
	LDY.w !RAM_SMW_OWSpr06_KoopaKid_WarpIndex,x
	STY.w !RAM_SMW_OWSpr06_KoopaKid_TileIndex
	REP.b #$20
endif
	JSR.w ResetKoopaKid
	INC.w !RAM_SMW_OWSpr06_KoopaKid_IsActiveFlag,x
Return:
	REP.b #$20
	RTL

KoopaKidActive:
if !bowsie_owrev == 1
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BEQ.b +
	JMP.w GFXRt

+:
endif
	LDA.w !RAM_SMW_OWSpr06_KoopaKid_StateTimer,x
	BNE.b ++
	INC.w !RAM_SMW_OWSpr06_KoopaKid_AnimationTimer,x
	%sub_update_x_pos()
	LDY.w !RAM_SMW_OWSpr_CurrentState,x
	LDA.w !RAM_SMW_OWSpr_XPosLo,x
	AND.w #$000F
	CMP.w DATA_04FB96,y
	BNE.b ++
	INC.w !RAM_SMW_OWSpr_CurrentState,x
	INC.w !RAM_SMW_OWSpr_CurrentState,x
	LDA.w !RAM_SMW_OWSpr_CurrentState,x
	CMP.w #$0004
	BCC.b +
EraseSprite:
	if !bowsie_owrev == 1
    	%erase_sprite()
	else
    	STZ.w !RAM_SMW_OWSpr06_KoopaKid_IsActiveFlag,x
	endif
	RTL

+:
	LDA.w #$0040
	STA.w !RAM_SMW_OWSpr_XSpeed,x
	LDA.w #$0060
	STA.w !RAM_SMW_OWSpr06_KoopaKid_StateTimer,x
++:
if !bowsie_owrev == 1
else
	%interact()
	BCS.b GFXRt
	SEP.b #$20
	LDA.b #$80
	TSB.w !RAM_SMW_Overworld_EnterLevelFlag
	REP.b #$20
endif
GFXRt:
	LDY.w !RAM_SMW_OWSpr_CurrentState,x
	LDA.w DATA_04FB94,y
	LDY.b #$00
	AND.w !RAM_SMW_OWSpr06_KoopaKid_AnimationTimer,x
	BNE.b +
	LDY.b #$02
+:
	LDA.w Prop,y
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w #$0000
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	STA.w oam_buffer[$00].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	STA.w oam_buffer[$00].y_pos,y
	LDA.b #!Define_SMW_OWSpr06_KoopaKid_Tile
	STA.w oam_buffer[$00].tile,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0F
	STA.w oam_buffer[$00].props,y
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0002
	LDA.w #$0000
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL


if !bowsie_owrev == 0
	pushpc
	org $048ECF				;	remap the AND table used by the Koopa Kid as the original one is destroyed ($80,$40,$20)
		dw $DCAE
	pullpc
endif

