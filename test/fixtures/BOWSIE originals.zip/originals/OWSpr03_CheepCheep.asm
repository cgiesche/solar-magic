
; Overworld sprite 03 - Cheep Cheep by yoshifanatic
; The cheep cheep sprite that hops out of the water in a few places in the original SMW.
; Unlike the original sprite, this version has no functionality to appear based on what tile Mario walks across.
; If not using Overworld Revolution, place it where you want it to spawn, then use the two extra bytes to specify the X/Y coordinates Mario needs to be to activate the cheep cheep.
; If you are using Overworld Revolution, then you can just spawn the cheep cheep through a script at any time desired with script command 2E. Placing it directly will just cause it to jump immediately.

incsrc "OriginalSMWSpriteDefines.asm"

if !bowsie_owrev == 1
!extra = 0
; No extra bytes for Overworld Revolution.
else
!extra = 2
;Extra bytes: 00 00
; 1 = X grid aligned coordinate of Mario
; 2 = Y grid aligned coordinate of Mario
endif

!Define_SMW_SpriteID_SpriteIDOfSplashEffect = $0F
!Define_SMW_OWSpr03_CheepCheep_Palette = $02
!Define_SMW_OWSpr03_CheepCheep_Tile1 = $004A
!Define_SMW_OWSpr03_CheepCheep_Tile2 = $0048

!RAM_SMW_OWSpr03_CheepCheep_InitialYPos #= !ow_sprite_misc_1
!RAM_SMW_OWSpr03_CheepCheep_AnimationFrameCounter #= !ow_sprite_misc_2
!RAM_SMW_OWSpr03_CheepCheep_IsActiveFlag #= !ow_sprite_misc_3
!RAM_SMW_OWSpr03_CheepCheep_XYCoordToCheck #= !RAM_SMW_OWSpr_ExtraByte1

Tiles:
	dw !Define_SMW_OWSpr03_CheepCheep_Tile1,!Define_SMW_OWSpr03_CheepCheep_Tile2

ResetCheepCheep:
	STZ.w !RAM_SMW_OWSpr03_CheepCheep_IsActiveFlag,x
	LDA.w #$0240
	STA.w !RAM_SMW_OWSpr_ZSpeed,x
	STZ.w !RAM_SMW_OWSpr_ZPosLo,x
	LDA.w !RAM_SMW_OWSpr03_CheepCheep_InitialYPos,x
	STA.w !RAM_SMW_OWSpr_YPosLo,x
	RTS

EraseSprite:
	JSR.w SpawnWaterSplash
EraseSprite2:
if !bowsie_owrev == 1
	%erase_sprite()
else
	STZ !RAM_SMW_OWSpr03_CheepCheep_IsActiveFlag,x
endif
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	SEP.b #$20
	JSL.l SMW_GetRand_Main
	REP.b #$20
	LDA.w !RAM_SMW_Misc_RandomByte1
	STA.w !RAM_SMW_OWSpr03_CheepCheep_AnimationFrameCounter,x
	LDA.w !RAM_SMW_OWSpr_ZPosLo,x
	CLC
	ADC.w !RAM_SMW_OWSpr_YPosLo,x
	STA.w !RAM_SMW_OWSpr03_CheepCheep_InitialYPos,x
	JSR.w ResetCheepCheep
main:
if !bowsie_owrev == 1
	%sub_offscreen()
	BCS.b EraseSprite2
endif
	LDA.w !RAM_SMW_OWSpr03_CheepCheep_IsActiveFlag,x
	BNE.b CheepCheepActive
if !bowsie_owrev == 1
else
	LDY.w !RAM_SMW_Player_CurrentCharacterX4Lo
	LDA.w !RAM_SMW_OWSpr03_CheepCheep_XYCoordToCheck,x
	SEP.b #$20
	CMP.w !RAM_SMW_Overworld_MarioGridAlignedXPosLo,y
	BNE.b Return
	XBA
	CMP.w !RAM_SMW_Overworld_MarioGridAlignedYPosLo,y
	BNE.b Return
	REP.b #$20
endif
	JSR.w ResetCheepCheep
	JSR.w SpawnWaterSplash
	LDY.b #!Define_SMW_Sound1DF9_Swim
	STY.w !RAM_SMW_IO_SoundCh1
	INC.w !RAM_SMW_OWSpr03_CheepCheep_IsActiveFlag,x
Return:
	REP.b #$20
	RTL

CheepCheepActive:
if !bowsie_owrev == 1
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BEQ.b +
	JMP.w GFXRt

+:
endif
	LDA.w !RAM_SMW_OWSpr_ZSpeed,x
	BPL.b +
	LDA.w !RAM_SMW_OWSpr_YPosLo,x
	SEC
	SBC.w !RAM_SMW_OWSpr_ZPosLo,x
	CMP.w !RAM_SMW_OWSpr03_CheepCheep_InitialYPos,x
	BCS.b EraseSprite
+:
	INC.w !RAM_SMW_OWSpr03_CheepCheep_AnimationFrameCounter,x
	%sub_update_z_pos()
	LDA.w !RAM_SMW_OWSpr_ZSpeed,x
	CLC
	ADC.w #$FFF0
	CMP.w #$FE30
	BEQ.b +
	STA.w !RAM_SMW_OWSpr_ZSpeed,x
+:
GFXRt:
	LDY.b #$08
	BIT.w !RAM_SMW_OWSpr_ZSpeed,x
	BMI.b +
	LDY.b #$10
+:
	TYA
	LDY.b #$00
	AND.w !RAM_SMW_OWSpr03_CheepCheep_AnimationFrameCounter,x
	AND.w #$00FF
	BEQ.b +
	LDY.b #$02
+:
	LDA.w !RAM_SMW_OWSpr_ZSpeed,x
	ROL
	LDA.w #$0000
	BCC.b +
	ORA.w #$C000
+:	
	ORA.w Tiles,y
	ORA.w #(!Define_SMW_OWSpr03_CheepCheep_Palette|$30)<<8
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w #$0001
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	%draw_vanilla_shadow()
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0000
	LDA.w #$0001
	%finish_oam_write()
	LDA.w #$0000
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	STA.w oam_buffer[$00].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	STA.w oam_buffer[$00].y_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0E
	STA.w oam_buffer[$00].tile,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0F
	STA.w oam_buffer[$00].props,y
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0002
	LDA.w #$0000
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL

SpawnWaterSplash:
	LDA.w #!Define_SMW_SpriteID_SpriteIDOfSplashEffect
	STA.b !RAM_SMW_Misc_ScratchRAM00
	LDA.w !RAM_SMW_OWSpr_XPosLo,x
	STA.b !RAM_SMW_Misc_ScratchRAM02
	LDA.w !RAM_SMW_OWSpr_YPosLo,x
	CLC
	ADC.w #$0008
	STA.b !RAM_SMW_Misc_ScratchRAM04
	STZ.b !RAM_SMW_Misc_ScratchRAM06
	STZ.b !RAM_SMW_Misc_ScratchRAM08
	%spawn_sprite()
	RTS
