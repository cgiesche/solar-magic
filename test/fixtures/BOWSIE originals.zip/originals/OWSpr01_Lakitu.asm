
; Overworld sprite 01 - Lakitu by yoshifanatic
; The unused lakitu sprite from the original SMW.
; Unlike the original, the "home in on Mario's position" functionality isn't included. It was unused anyway even when spawning in the sprite, so it's not like it matters.
; There are no restrictions on placement compared to the original game. Place as many as you desire.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_OWSpr01_Lakitu_Palette = $02
!Define_SMW_OWSpr01_Lakitu_HeadTile = $0026
!Define_SMW_OWSpr01_Lakitu_CloudTile = $0028

!RAM_SMW_OWSpr01_Lakitu_FollowMarioRangeIndex #= !ow_sprite_misc_1
!RAM_SMW_OWSpr01_Lakitu_HorizAndVertMovementDirection #= !ow_sprite_misc_2				; Note: Also affects movement in the Z axis
!RAM_SMW_OWSpr01_Lakitu_AnimationFrameCounter #= !ow_sprite_misc_3

Acceleration:
	dw $0010,$FFF0

MaxSpeed:
	dw $0100,$FF00

DATA_04F8B6:
	dw $0010,$0008,$0020,$0020

DATA_04F8BE:
	dw $0010,$0030,$0008,$0010

CloudXDisp:
	dw $0001,$0003,$0001,$0001
	dw $0001,$0001,$0001,$0002

CloudYDisp:
	dw $000C,$0012,$0012,$000C
	dw $000C,$0012,$0012,$000C

EraseSprite:
	%erase_sprite()
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_ProcessWhenOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	SEP.b #$20
	JSL.l SMW_GetRand_Main
	REP.b #$20
	LDA.w !RAM_SMW_Misc_RandomByte1
	STA.w !RAM_SMW_OWSpr01_Lakitu_AnimationFrameCounter,x
	LDA.w #$0040
	STA.w !RAM_SMW_OWSpr_ZPosLo,x
main:
if !bowsie_owrev == 1
	%sub_offscreen()
	BCS.b EraseSprite
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BEQ.b +
	JMP.w GFXRt

+:
endif
	INC.w !RAM_SMW_OWSpr01_Lakitu_AnimationFrameCounter,x
	LDA.w !RAM_SMW_OWSpr01_Lakitu_HorizAndVertMovementDirection,x
	AND.w #$0002
	EOR.w #$0002
	TAY
	LDA.w !RAM_SMW_OWSpr_ZSpeed,x
	CLC
	ADC.w Acceleration,y
	STA.w !RAM_SMW_OWSpr_ZSpeed,x
	CMP.w MaxSpeed,y
	BNE.b +
	LDA.w !RAM_SMW_OWSpr01_Lakitu_HorizAndVertMovementDirection,x
	EOR.w #$0002
	STA.w !RAM_SMW_OWSpr01_Lakitu_HorizAndVertMovementDirection,x
+:
	%distance()
	LDY.w !RAM_SMW_OWSpr01_Lakitu_FollowMarioRangeIndex,x
	LDA.w !RAM_SMW_OWSpr01_Lakitu_HorizAndVertMovementDirection-$01,x
	ASL
	EOR.b !RAM_SMW_Misc_ScratchRAM00
	BPL.b +
	LDA.b !RAM_SMW_Misc_ScratchRAM06
	CMP.w DATA_04F8B6,y
	LDA.w #$0040
	BCS.b ++
+:
	LDA.w !RAM_SMW_OWSpr01_Lakitu_HorizAndVertMovementDirection-$01,x
	EOR.b !RAM_SMW_Misc_ScratchRAM02
	ASL
	BCC.b ++
	LDA.b !RAM_SMW_Misc_ScratchRAM08
	CMP.w DATA_04F8BE,y
	LDA.w #$0080
++:
	BCC.b +
	EOR.w !RAM_SMW_OWSpr01_Lakitu_HorizAndVertMovementDirection,x
	STA.w !RAM_SMW_OWSpr01_Lakitu_HorizAndVertMovementDirection,x
	SEP.b #$20
	JSL.l SMW_GetRand_Main
	REP.b #$20
	AND.w #$0006
	STA.w !RAM_SMW_OWSpr01_Lakitu_FollowMarioRangeIndex,x
+:
	LDA.w !RAM_SMW_OWSpr01_Lakitu_HorizAndVertMovementDirection,x
	AND.w #$0040
	ASL
	ASL
	ASL
	XBA
	EOR.w #$0002
	TAY
	LDA.w !RAM_SMW_OWSpr_XSpeed,x
	CLC
	ADC.w Acceleration,y
	CMP.w MaxSpeed,y
	BEQ.b +
	STA.w !RAM_SMW_OWSpr_XSpeed,x
+:
	LDA.w !RAM_SMW_OWSpr01_Lakitu_HorizAndVertMovementDirection,x
	AND.w #$0080
	ASL
	ASL
	XBA
	EOR.w #$0002
	TAY
	LDA.w !RAM_SMW_OWSpr_YSpeed,x
	CLC
	ADC.w Acceleration,y
	CMP.w MaxSpeed,y
	BEQ.b +
	STA.w !RAM_SMW_OWSpr_YSpeed,x
+:
	%sub_update_x_pos()
	%sub_update_y_pos()
	%sub_update_z_pos()
GFXRt:
	LDA.w !RAM_SMW_OWSpr01_Lakitu_AnimationFrameCounter,x
	AND.w #$0010
	LSR
	ORA.w #$0006
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w #$0001
	SEC
	%get_draw_info()
	BCC.b .SpriteOnScreen
	JMP.w .SpriteOffScreen

.SpriteOnScreen:
	%maxtile_set_databank()
	SEP.b #$20
	%draw_vanilla_shadow()
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0000
	LDA.w #$0001
	%finish_oam_write()
	LDA.w #$0004
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	LDA.l !RAM_SMW_OAM_MaxTileOAMBufferIndex2
	STA.b !RAM_SMW_Misc_ScratchRAM0C
	SEP.b #$20
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	STA.w oam_buffer[$00].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	STA.w oam_buffer[$00].y_pos,y
	LDA.b #!Define_SMW_OWSpr01_Lakitu_HeadTile
	STA.w oam_buffer[$00].tile,y
	LDA.b #!Define_SMW_OWSpr01_Lakitu_Palette|$30
	STA.w oam_buffer[$00].props,y
	LDX.b !RAM_SMW_Misc_ScratchRAM0C
	LDA.b #$02
	STA.w oam_tilesize_buffer[$00].tile_sx,x
	LDX.w #$0003
-:
	PHX
	LDX.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	CLC
	ADC.l CloudXDisp,x
	STA.b !RAM_SMW_Misc_ScratchRAM00
	STA.w oam_buffer[$01].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	CLC
	ADC.l CloudYDisp,x
	STA.w oam_buffer[$01].y_pos,y
	LDA.b #!Define_SMW_OWSpr01_Lakitu_CloudTile
	STA.w oam_buffer[$01].tile,y
	LDA.b #!Define_SMW_OWSpr01_Lakitu_Palette|$30
	STA.w oam_buffer[$01].props,y
	LDX.b !RAM_SMW_Misc_ScratchRAM0C
	STZ.w oam_tilesize_buffer[$01].tile_sx,x
	INX
	STX.b !RAM_SMW_Misc_ScratchRAM0C
	PLX
	INY
	INY
	INY
	INY
	DEC.b !RAM_SMW_Misc_ScratchRAM0E
	DEC.b !RAM_SMW_Misc_ScratchRAM0E
	DEX
	BPL.b -
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$FFFF
	LDA.w #$0004
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
