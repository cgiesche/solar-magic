
; Overworld sprite 08 - Bowser by yoshifanatic
; This is the bowser sprite that flies around Bowser's castle in a figure 8 pattern.
; There are no restrictions on placement compared to the original game. Place as many as you desire.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_OWSpr09_Bowser_Palette = $00
!Define_SMW_OWSpr09_Bowser_Tile = $0068

!RAM_SMW_OWSpr09_Bowser_HorizontalMovementDirection #= !ow_sprite_misc_1
!RAM_SMW_OWSpr09_Bowser_VerticalMovementDirection #= !ow_sprite_misc_2
!RAM_SMW_OWSpr09_Bowser_MovementFrameCounter #= !ow_sprite_misc_3

Acceleration:
	dw $0008,$FFF8

MaxXSpeed:
	dw $0180,$FE80
	
MaxYSpeed:
	dw $00A0,$FF60

Prop:
	dw (!Define_SMW_OWSpr09_Bowser_Palette)<<8,(!Define_SMW_OWSpr09_Bowser_Palette|$40)<<8

EraseSprite:
	%erase_sprite()
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
main:
if !bowsie_owrev == 1
	%sub_offscreen()
	BCS.b EraseSprite
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BEQ.b +
	JMP.w GFXRt

+:
endif
	%sub_update_x_pos()
	%sub_update_y_pos()
	LDY.w !RAM_SMW_OWSpr09_Bowser_HorizontalMovementDirection,x
	LDA.w !RAM_SMW_OWSpr_XSpeed,x
	CLC
	ADC.w Acceleration,y
	STA.w !RAM_SMW_OWSpr_XSpeed,x
	CMP.w MaxXSpeed,y
	BNE.b +
	LDA.w !RAM_SMW_OWSpr09_Bowser_HorizontalMovementDirection,x
	EOR.w #$0002
	STA.w !RAM_SMW_OWSpr09_Bowser_HorizontalMovementDirection,x
+:
	LDY.w !RAM_SMW_OWSpr09_Bowser_VerticalMovementDirection,x
	LDA.w !RAM_SMW_OWSpr_YSpeed,x
	CLC
	ADC.w Acceleration,y
	STA.w !RAM_SMW_OWSpr_YSpeed,x
	CMP.w MaxYSpeed,y
	BNE.b +
	LDA.w !RAM_SMW_OWSpr09_Bowser_VerticalMovementDirection,x
	EOR.w #$0002
	STA.w !RAM_SMW_OWSpr09_Bowser_VerticalMovementDirection,x
+:
GFXRt:
	LDY.b #$00
	LDA.w !RAM_SMW_OWSpr_XSpeed,x
	BMI.b +
	LDY.b #$02
+:
	LDA.w Prop,y
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w #$0000
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$21
	LDA.b !RAM_SMW_Misc_ScratchRAM00
if !bowsie_owrev == 1
	SBC.b #$08
endif
	STA.w oam_buffer[$00].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	STA.w oam_buffer[$00].y_pos,y
	LDA.b #!Define_SMW_OWSpr09_Bowser_Tile
	STA.w oam_buffer[$00].tile,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0F
	STA.w oam_buffer[$00].props,y
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0002
	LDA.w #$0000
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
