
; Overworld sprite 07 - Yoshi's House Smoke by yoshifanatic
; The 3 smoke puffs coming from the chimney of Yoshi's House.
; There are no restrictions on placement compared to the original game. Place as many as you desire.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_OWSpr07_Smoke_Palette = $00
!Define_SMW_OWSpr07_Smoke_Tile1 = $0028
!Define_SMW_OWSpr07_Smoke_Tile2 = $005F

!RAM_SMW_OWSpr07_Smoke_AnimationFrameCounter #= !ow_sprite_misc_1

XDisp:
	db $09,$0A,$0B,$0C,$0B,$0A,$09,$08
	db $09,$0A,$0B,$0C,$0B,$0A,$09,$08

YDisp:
	db $FF,$FF,$FE,$FD,$FD,$FC,$FB,$FB
	db $FA,$F9,$F9,$F8,$F7,$F7,$F6,$F5

EraseSprite:
	%erase_sprite()
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	LDA.w !RAM_SMW_OWSpr_YPosLo,x
	CLC
if !bowsie_owrev == 1
	ADC.w #$000A
else
	ADC.w #$0002
endif
	STA.w !RAM_SMW_OWSpr_YPosLo,x
main:
if !bowsie_owrev == 1
	%sub_offscreen()
	BCS.b EraseSprite
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BEQ.b +
	JMP.w GFXRt

+:
endif
	LDA.b !RAM_SMW_Counter_LocalFrames
	AND.w #$000F
	BNE.b ++
	LDA.w !RAM_SMW_OWSpr07_Smoke_AnimationFrameCounter,x
	INC
	CMP.w #$000C
	BCC.b +
	LDA.w #$0000
+:
	STA.w !RAM_SMW_OWSpr07_Smoke_AnimationFrameCounter,x
++:
GFXRt:
	LDA.w !RAM_SMW_OWSpr07_Smoke_AnimationFrameCounter,x
	STA.b !RAM_SMW_Misc_ScratchRAM0A
	LDA.b !RAM_SMW_Counter_LocalFrames
	AND.w #$00FF
	STA.b !RAM_SMW_Misc_ScratchRAM0C
	STZ.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w #$0002
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	LDX.w #$0002
	BRA.b ++

-:
	LDA.b !RAM_SMW_Misc_ScratchRAM0A
	CLC
	ADC.b #$0C
	CMP.b #$10
	AND.b #$0F
	STA.b !RAM_SMW_Misc_ScratchRAM0A
	BCC.b +
	LDA.b !RAM_SMW_Misc_ScratchRAM0E
	SBC.b #$0C
	STA.b !RAM_SMW_Misc_ScratchRAM0E
+:
++:
	PHX
	LDX.b !RAM_SMW_Misc_ScratchRAM0A
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	CLC
	ADC.l XDisp,x
	STA.w oam_buffer[$00].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	CLC
	ADC.l YDisp,x
	CLC
	ADC.b !RAM_SMW_Misc_ScratchRAM0E
	STA.w oam_buffer[$00].y_pos,y
	LDX.w #!Define_SMW_OWSpr07_Smoke_Tile1
	LDA.b !RAM_SMW_Misc_ScratchRAM0C
	CLC
	ADC.b #$0A
	STA.b !RAM_SMW_Misc_ScratchRAM0C
	AND.b #$20
	BEQ.b +
	LDX.w #!Define_SMW_OWSpr07_Smoke_Tile2
+:
	TXA
	STA.w oam_buffer[$00].tile,y
	PLX
	LDA.b #!Define_SMW_OWSpr07_Smoke_Palette|$30
	STA.w oam_buffer[$00].props,y
	INY
	INY
	INY
	INY
	DEX
	BPL.b -
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0000
	LDA.w #$0002
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
