
; Overworld sprite 0E - Destroy Tile Smoke by yoshifanatic
; This will display a smoke effect, like how the destroyed castles/switch palaces do in the original SMW, except no longer tied to that event.
; While you can place this, it's better to spawn it within another sprite's code or through a script.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_OWSpr0E_DestroyTileSmoke_Palette = $06

!RAM_SMW_OWSpr0E_DestroyTileSmoke_AnimationTimer #= !ow_sprite_timer_1

Tiles:
	dw $0073
	dw $0073
	dw $0072
	dw $0072
	dw $005F
	dw $005F
	dw $0028
	dw $0028
	dw $0028
	dw $0028
	dw $0028

XDisp:
	db $F5,$11,$F2,$15
	db $F5,$11,$F3,$14
	db $F5,$11,$F3,$14
	db $F6,$10,$F4,$13
	db $F7,$0F,$F5,$12
	db $F8,$0E,$F7,$11
	db $FA,$0D,$F9,$10
	db $FC,$0C,$FB,$0D
	db $FF,$0A,$FE,$0B
	db $01,$07,$01,$07

YDisp:
	db $F7,$F7,$10,$11
	db $F7,$F7,$0F,$10
	db $F7,$F7,$0F,$10
	db $F8,$F8,$0E,$0F
	db $F9,$F9,$0D,$0E
	db $FA,$FA,$0B,$0C
	db $FB,$FB,$0A,$0A
	db $FD,$FD,$09,$09
	db $FF,$FF,$07,$07
	db $00,$00,$06,$06

Flip:
	db $00,$40,$80,$C0

EraseSprite:
	%erase_sprite()
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	LDA.w #$0027
	STA.w !RAM_SMW_OWSpr0E_DestroyTileSmoke_AnimationTimer,x
	LDY.b #!Define_SMW_Sound1DFC_CastleCollapse
	STY.w !RAM_SMW_IO_SoundCh3
main:
	%sub_offscreen()
	BCS.b EraseSprite
if !bowsie_owrev == 1
	;LDA.b !RAM_SMW_Flag_SpritesLocked
	;BEQ.b +
	;JMP.w GFXRt

;+:
endif
	LDA.w !RAM_SMW_OWSpr0E_DestroyTileSmoke_AnimationTimer,x
	BEQ.b EraseSprite
	AND.w #$003C
	LSR
	TAY
	LDA.w Tiles,y
	ORA.w #(!Define_SMW_OWSpr0E_DestroyTileSmoke_Palette|$30)<<8
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	TYA
	ASL
	ADC.w #$0003
	STA.b !RAM_SMW_Misc_ScratchRAM0C
	LDA.w #$0003
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	LDX.w #$0003
-:
	PHX
	LDX.b !RAM_SMW_Misc_ScratchRAM0C
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	CLC
	ADC.l XDisp,x
	STA.w oam_buffer[$00].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	CLC
	ADC.l YDisp,x
	STA.w oam_buffer[$00].y_pos,y
	PLX
	LDA.b !RAM_SMW_Misc_ScratchRAM0E
	STA.w oam_buffer[$00].tile,y
	LDA.l Flip,x
	ORA.b !RAM_SMW_Misc_ScratchRAM0F
	STA.w oam_buffer[$00].props,y
	INY
	INY
	INY
	INY
	DEC.b !RAM_SMW_Misc_ScratchRAM0C
	DEX
	BPL.b -
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0000
	LDA.w #$0003
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
