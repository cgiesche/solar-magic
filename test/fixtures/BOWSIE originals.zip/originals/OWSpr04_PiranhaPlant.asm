
; Overworld sprite 04 - Piranha Plant by yoshifanatic
; The unused piranha plant sprite.
; There are no restrictions on placement compared to the original game. Place as many as you desire.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_OWSpr04_PiranhaPlant_Palette = $02
!Define_SMW_OWSpr04_PiranhaPlant_Tile1 = $002A
!Define_SMW_OWSpr04_PiranhaPlant_Tile2 = $002C

!RAM_SMW_OWSpr04_PiranhaPlant_AnimationFrameCounter #= !ow_sprite_misc_1

Tiles:
	dw !Define_SMW_OWSpr04_PiranhaPlant_Tile1,!Define_SMW_OWSpr04_PiranhaPlant_Tile2

EraseSprite:
	%erase_sprite()
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	SEP.b #$20
	JSL.l SMW_GetRand_Main
	REP.b #$20
	LDA.w !RAM_SMW_Misc_RandomByte1
	STA.w !RAM_SMW_OWSpr04_PiranhaPlant_AnimationFrameCounter,x
main:
if !bowsie_owrev == 1
	%sub_offscreen()
	BCS.b EraseSprite
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BNE.b GFXRt
endif
	INC.w !RAM_SMW_OWSpr04_PiranhaPlant_AnimationFrameCounter,x
GFXRt:
	LDY.b #$00
	LDA.w !RAM_SMW_OWSpr04_PiranhaPlant_AnimationFrameCounter,x
	AND.w #$0008
	BEQ.b +
	LDY.b #$02
+:
	LDA.w Tiles,y
	ORA.w #(!Define_SMW_OWSpr04_PiranhaPlant_Palette|$30)<<8
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w #$0000
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	STA.w oam_buffer[$00].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	STA.w oam_buffer[$00].y_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0E
	STA.w oam_buffer[$00].tile,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0F
	STA.w oam_buffer[$00].props,y
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0002
	LDA.w #$0000
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
