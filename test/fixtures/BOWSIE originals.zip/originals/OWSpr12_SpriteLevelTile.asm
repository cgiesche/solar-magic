
; Overworld sprite 12 - Sprite Level Tile by yoshifanatic
; This is a sprite based version of the level tiles you'd usually place on layer 1, allowing layer 1 to be freed up further if desired.
; You still need to place the layer 1 tiles down, but you can vary their appearance instead of being forced to make them look like level tiles.
; 
;Extra bytes: 0000 0000 00
; 1-2 = Map16 ID (Not used, but could be in the future)
; 3-4 = Event table index
; 5 = Tile appearance table index

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 5

!RAM_SMW_OWSpr12_SpriteLevelTile_ParameterPtrLo #= !RAM_SMW_OWSpr_ExtraByte1
!RAM_SMW_OWSpr12_SpriteLevelTile_ParameterPtrHi #= !RAM_SMW_OWSpr_ExtraByte2
!RAM_SMW_OWSpr12_SpriteLevelTile_ParameterPtrBank #= !RAM_SMW_OWSpr_ExtraByte3

BitTable:
	db $01,$02,$04,$08,$10,$20,$40,$80

EventTablePtrs:									; Which events will allow a particular level tile to appear. Indexed by the 3rd and 4th extra byte's value
	dw Level000TileEvents
.End:

; Data format:
; 1 = Number of events
; 2-3 = Event ID
; Repeat 2-3 for each additional event.

Level000TileEvents:
	db (Level000TileEvents_End-Level000TileEvents-$01)/$02
	dw $0001,$0003
.End:

TileAppearanceTablePtrs:
	dw YellowSmallDotTileData
	dw RedSmallDotTileData
	dw YellowBigDotTileData
	dw RedBigDotTileData
	dw GhostHouseTileData
	dw YoshisHouseTileData
	dw PipeTileData
	dw StarRoadTileData
	dw CastleTileData
	dw FortressTileData
	dw YellowSwitchPalaceTileData
	dw GreenSwitchPalaceTileData
	dw RedSwitchPalaceTileData
	dw BlueSwitchPalaceTileData
	dw DestroyedCastleTileData
	dw DestroyedYellowSwitchPalaceTileData
	dw DestroyedGreenSwitchPalaceTileData
	dw DestroyedRedSwitchPalaceTileData
	dw DestroyedBlueSwitchPalaceTileData
	dw YellowCaveTileData
	dw RedCaveTileData
.End:

; Data format: 
; 1 = Number of tiles
; 2-3 = X Disp
; 4-5 = Y Disp
; 6-7 = Tile ID and YXPPCCCT properties
; Repeat 2-7 for each additional tile

YellowSmallDotTileData:
	db $01
	dw $0000,$0000,$28C8

RedSmallDotTileData:
	db $01
	dw $0000,$0000,$2AC8

YellowBigDotTileData:
	db $01
	dw $0000,$0000,$28C6

RedBigDotTileData:
	db $01
	dw $0000,$0000,$2AC6

GhostHouseTileData:
	db $01
	dw $0000,$0000,$28C0

YoshisHouseTileData:
	db $01
	dw $0000,$0000,$2AEA

PipeTileData:
	db $01
	dw $0000,$0000,$2CC2

StarRoadTileData:
	db $01
	dw $0000,$0000,$28EE

CastleTileData:
	db $02
	dw $0000,$0000,$2CCE
	dw $0000,$FFF0,$2CAE

FortressTileData:
	db $01
	dw $0000,$0000,$2CEC

YellowSwitchPalaceTileData:
	db $01
	dw $0000,$0000,$20CA

GreenSwitchPalaceTileData:
	db $01
	dw $0000,$0000,$26CA

RedSwitchPalaceTileData:
	db $01
	dw $0000,$0000,$24CA

BlueSwitchPalaceTileData:
	db $01
	dw $0000,$0000,$22CA

DestroyedCastleTileData:
	db $01
	dw $0000,$0000,$2CCC

DestroyedYellowSwitchPalaceTileData:
	db $01
	dw $0000,$0000,$20C4

DestroyedGreenSwitchPalaceTileData:
	db $01
	dw $0000,$0000,$26C4

DestroyedRedSwitchPalaceTileData:
	db $01
	dw $0000,$0000,$24C4

DestroyedBlueSwitchPalaceTileData:
	db $01
	dw $0000,$0000,$22C4

YellowCaveTileData:
	db $01
	dw $0000,$0000,$28E8

RedCaveTileData:
	db $01
	dw $0000,$0000,$2AE8

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	LDY.b #$02
	LDA.b [!RAM_SMW_Misc_ScratchRAM00],y
	XBA
	ASL
	CMP.w #EventTablePtrs_End-EventTablePtrs
	BCC.b +
	LDA.w #$0000
+:
	TAY
	LDA.w EventTablePtrs,y
	STA.b !RAM_SMW_Misc_ScratchRAM0D
	LDA.b (!RAM_SMW_Misc_ScratchRAM0D)
	AND.w #$00FF
	INC.b !RAM_SMW_Misc_ScratchRAM0D
	STA.b !RAM_SMW_Misc_ScratchRAM0B
	BEQ.b +
	PHX
	REP.b #$10
-:
	LDA.b (!RAM_SMW_Misc_ScratchRAM0D)
	JSL.l GetEventIndex
	SEP.b #$20
	LDA.w !RAM_SMW_Overworld_EventFlags,y
	AND.l BitTable,x
	REP.b #$20
	BNE.b +
	INC.b !RAM_SMW_Misc_ScratchRAM0D
	INC.b !RAM_SMW_Misc_ScratchRAM0D
	DEC.b !RAM_SMW_Misc_ScratchRAM0B
	BNE.b -
	SEP.b #$10
	PLX
EraseSprite:
	%erase_sprite()
	RTL

+:
	SEP.b #$10
	PLX
main:
if !bowsie_owrev == 1
	%sub_offscreen()
	BCS.b EraseSprite
endif
	LDA.w !RAM_SMW_OWSpr12_SpriteLevelTile_ParameterPtrLo,x
	STA.b !RAM_SMW_Misc_ScratchRAM00
	LDA.w !RAM_SMW_OWSpr12_SpriteLevelTile_ParameterPtrBank,x
	STA.b !RAM_SMW_Misc_ScratchRAM02
GFXRt:
	LDY.b #$04
	LDA.b [!RAM_SMW_Misc_ScratchRAM00],y
	AND.w #$00FF
	ASL
	CMP.w #TileAppearanceTablePtrs_End-TileAppearanceTablePtrs
	BCC.b +
	LDA.b #$0000
+:
	TAY
	LDA.w TileAppearanceTablePtrs,y
	STA.b !RAM_SMW_Misc_ScratchRAM0D
	LDY.b #TileAppearanceTablePtrs>>16
	STY.b !RAM_SMW_Misc_ScratchRAM0F
	LDA.b (!RAM_SMW_Misc_ScratchRAM0D)
	INC.b !RAM_SMW_Misc_ScratchRAM0D
	AND.w #$00FF
	DEC
	STA.b !RAM_SMW_Misc_ScratchRAM0B
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	LDA.b !RAM_SMW_Misc_ScratchRAM0B
	STA.b !RAM_SMW_Misc_ScratchRAM09
-:
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	CLC
	ADC.b [!RAM_SMW_Misc_ScratchRAM0D]
	STA.w oam_buffer[$00].x_pos,y
	JSR.w IncrementPtr
	JSR.w IncrementPtr
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	CLC
	ADC.b [!RAM_SMW_Misc_ScratchRAM0D]
	STA.w oam_buffer[$00].y_pos,y
	JSR.w IncrementPtr
	JSR.w IncrementPtr
	LDA.b [!RAM_SMW_Misc_ScratchRAM0D]
	STA.w oam_buffer[$00].tile,y
	JSR.w IncrementPtr
	LDA.b [!RAM_SMW_Misc_ScratchRAM0D]
	STA.w oam_buffer[$00].props,y
	JSR.w IncrementPtr
	INY
	INY
	INY
	INY
	DEC.b !RAM_SMW_Misc_ScratchRAM0B
	BPL.b -
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0002
	LDA.b !RAM_SMW_Misc_ScratchRAM09
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL

IncrementPtr:
	INC.b !RAM_SMW_Misc_ScratchRAM0D
	BNE.b +
	INC.b !RAM_SMW_Misc_ScratchRAM0E
+:
	RTS

if !bowsie_owrev != 1
GetEventIndex:
	LDY.w #$0000
	BRA.b +

-:
	SBC.w #$0008
+:
	CMP.w #$0008
	BCC.b +
	INY
	BRA.b -

+:
	TAX
	RTL
endif
