
; Overworld sprite 11 - Cloud Generator by yoshifanatic
; This will randomly spawn clouds throughout the current map, similar to how the main map does in the original SMW.
; If not using Overworld Revolution, place it wherever on the map to have it run.
; If using Overworld Revolution, spawn it through a silent event script so it loads regardless of the camera position.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_SpriteID_SpriteIDOfCloud = $05

XOffset:
	dw $FFE0,$0020,$00C0,$FFE0
	dw $FFE0,$0080,$FFE0,$0000

YOffset:
	dw $0070,$00E0,$00E0,$00B0
	dw $00E0,$00E0,$0070,$00E0

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_ProcessWhenOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
main:
if !bowsie_owrev == 1
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BNE.b +
endif
	JSR.w SpawnCloud
+:
	RTL

SpawnCloud:
	SEP.b #$20
	JSL.l SMW_GetRand_Main
	REP.b #$21
	LDA.b !RAM_SMW_Counter_LocalFrames 
	AND.w #$00FF
	BNE.b .Return
	LDA.w !RAM_SMW_Misc_RandomByte1
	AND.w #$0030
	BNE.b .Return
	LDA.w #!Define_SMW_SpriteID_SpriteIDOfCloud
	STA.b !RAM_SMW_Misc_ScratchRAM00
	LDA.w !RAM_SMW_Misc_RandomByte1
	AND.w #$000E
	TAY
	LDA.b !RAM_SMW_Mirror_CurrentLayer1XPosLo
	ADC.w XOffset,y
	STA.b !RAM_SMW_Misc_ScratchRAM02
	LDA.b !RAM_SMW_Mirror_CurrentLayer1YPosLo
	CLC
	ADC.w YOffset,y
	STA.b !RAM_SMW_Misc_ScratchRAM04
	STZ.b !RAM_SMW_Misc_ScratchRAM06
	STZ.b !RAM_SMW_Misc_ScratchRAM08
	%spawn_sprite()
.Return:
	RTS
