
; Overworld sprite 0A - Boo by yoshifanatic
; The boo that flies around ghost house tiles in the original SMW.
; Unlike the original sprite, this version has no functionality to appear based on an event.
; When using Overworld Revolution, you can just spawn the boo through scripts using script command 2E to do the same thing.
; There are also no restrictions on placement either compared to the original game. Place as many as you desire.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_OWSpr0A_Boo_Palette = $04
!Define_SMW_OWSpr0A_Boo_Tile = $0060

!RAM_SMW_OWSpr0A_Boo_HorizontalMovementDirection #= !ow_sprite_misc_1
!RAM_SMW_OWSpr0A_Boo_VerticalMovementDirection #= !ow_sprite_misc_2
!RAM_SMW_OWSpr0A_Boo_MovementFrameCounter #= !ow_sprite_misc_3

XAcceleration:
	dw $0002,$FFFE

YAcceleration:
	dw $0004,$FFFC

MaxXSpeed:
	dw $0080,$FF80
	
MaxYSpeed:
	dw $0030,$FFD0

Prop:
	dw (!Define_SMW_OWSpr0A_Boo_Palette|$30)<<8,(!Define_SMW_OWSpr0A_Boo_Palette|$40)<<8

EraseSprite:
	%erase_sprite()
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
main:
if !bowsie_owrev == 1
	%sub_offscreen()
	BCS.b EraseSprite
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BEQ.b +
	JMP.w GFXRt

+:
endif
	%sub_update_x_pos()
	%sub_update_y_pos()
	LDY.w !RAM_SMW_OWSpr0A_Boo_HorizontalMovementDirection,x
	LDA.w !RAM_SMW_OWSpr_XSpeed,x
	CLC
	ADC.w XAcceleration,y
	STA.w !RAM_SMW_OWSpr_XSpeed,x
	CMP.w MaxXSpeed,y
	BNE.b +
	LDA.w !RAM_SMW_OWSpr0A_Boo_HorizontalMovementDirection,x
	EOR.w #$0002
	STA.w !RAM_SMW_OWSpr0A_Boo_HorizontalMovementDirection,x
+:
	LDY.w !RAM_SMW_OWSpr0A_Boo_VerticalMovementDirection,x
	LDA.w !RAM_SMW_OWSpr_YSpeed,x
	CLC
	ADC.w YAcceleration,y
	STA.w !RAM_SMW_OWSpr_YSpeed,x
	CMP.w MaxYSpeed,y
	BNE.b +
	LDA.w !RAM_SMW_OWSpr0A_Boo_VerticalMovementDirection,x
	EOR.w #$0002
	STA.w !RAM_SMW_OWSpr0A_Boo_VerticalMovementDirection,x
+:
GFXRt:
	LDY.b #$00
	LDA.w !RAM_SMW_OWSpr_XSpeed,x
	BMI.b +
	LDY.b #$02
+:
	LDA.w Prop,y
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w #$0000
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$21
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	STA.w oam_buffer[$00].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
if !bowsie_owrev == 1
	SBC.b #$07
endif
	STA.w oam_buffer[$00].y_pos,y
	LDA.b #!Define_SMW_OWSpr0A_Boo_Tile
	STA.w oam_buffer[$00].tile,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0F
	STA.w oam_buffer[$00].props,y
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0002
	LDA.w #$0000
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
