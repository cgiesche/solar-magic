
; Overworld sprite 0B - Level Appear Sparkle by yoshifanatic
; This will spawn a sparkle effect, like seen when a level appears in the original SMW.
; While you can place this, it's better to spawn it within another sprite's code or through a script.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_OWSpr0B_LevelAppearSparkle_Palette = $00

!RAM_SMW_OWSpr0B_LevelAppearSparkle_AnimationTimer #= !ow_sprite_timer_1

Tiles:
	dw $0022,$0023,$0032,$0033,$0032,$0023,$0022

XDisp:
	db $00,$08,$00,$08

YDisp:
	db $FF,$FF,$07,$07

Flip:
	db $00,$40,$80,$C0

EraseSprite:
	%erase_sprite()
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	LDA.w #$001B
	STA.w !RAM_SMW_OWSpr0B_LevelAppearSparkle_AnimationTimer,x
	LDY.b #!Define_SMW_Sound1DFC_Coin
	STY.w !RAM_SMW_IO_SoundCh3
main:
	%sub_offscreen()
	BCS.b EraseSprite
if !bowsie_owrev == 1
	;LDA.b !RAM_SMW_Flag_SpritesLocked
	;BEQ.b +
	;JMP.w GFXRt

;+:
endif
	LDA.w !RAM_SMW_OWSpr0B_LevelAppearSparkle_AnimationTimer,x
	BEQ.b EraseSprite
	AND.w #$001C
	LSR
	TAY
	LDA.w Tiles,y
	ORA.w #(!Define_SMW_OWSpr0B_LevelAppearSparkle_Palette|$30)<<8
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w #$0003
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	LDX.w #$0003
-:
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	CLC
	ADC.l XDisp,x
	STA.w oam_buffer[$00].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	CLC
	ADC.l YDisp,x
	STA.w oam_buffer[$00].y_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0E
	STA.w oam_buffer[$00].tile,y
	LDA.l Flip,x
	ORA.b !RAM_SMW_Misc_ScratchRAM0F
	STA.w oam_buffer[$00].props,y
	INY
	INY
	INY
	INY
	DEX
	BPL.b -
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0000
	LDA.w #$0003
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
