
; Overworld sprite 08 - Bowser Sign by yoshifanatic
; The glowing neon sign hanging in front of Bowser's Castle.
; There are no restrictions on placement compared to the original game. Place as many as you desire.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_OWSpr08_BowserSign_Tile1 = $006C
!Define_SMW_OWSpr08_BowserSign_Tile2 = $006D
!Define_SMW_OWSpr08_BowserSign_Tile3 = $006E
!Define_SMW_OWSpr08_BowserSign_Tile4 = $006F

EraseSprite:
	%erase_sprite()
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
	LDA.w !RAM_SMW_OWSpr_YPosLo,x
	CLC
	ADC.w #$0008
	STA.w !RAM_SMW_OWSpr_YPosLo,x
endif
main:
if !bowsie_owrev == 1
	%sub_offscreen()
	BCS.b EraseSprite
	;LDA.b !RAM_SMW_Flag_SpritesLocked
	;BEQ.b +
	;JMP.w GFXRt

;+:
endif
	LDA.b !RAM_SMW_Counter_LocalFrames-$01
	LSR
	AND.w #$0600
	ORA.w #$3000
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w #$0003
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	STA.w oam_buffer[$00].x_pos,y
	CLC
	ADC.b #$08
	STA.w oam_buffer[$01].x_pos,y
	CLC
	ADC.b #$08
	STA.w oam_buffer[$02].x_pos,y
	CLC
	ADC.b #$08
	STA.w oam_buffer[$03].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	STA.w oam_buffer[$00].y_pos,y
	STA.w oam_buffer[$01].y_pos,y
	STA.w oam_buffer[$02].y_pos,y
	STA.w oam_buffer[$03].y_pos,y
	LDA.b #!Define_SMW_OWSpr08_BowserSign_Tile1
	STA.w oam_buffer[$00].tile,y
	LDA.b #!Define_SMW_OWSpr08_BowserSign_Tile2
	STA.w oam_buffer[$01].tile,y
	LDA.b #!Define_SMW_OWSpr08_BowserSign_Tile3
	STA.w oam_buffer[$02].tile,y
	LDA.b #!Define_SMW_OWSpr08_BowserSign_Tile4
	STA.w oam_buffer[$03].tile,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0F
	STA.w oam_buffer[$00].props,y
	STA.w oam_buffer[$01].props,y
	STA.w oam_buffer[$02].props,y
	STA.w oam_buffer[$03].props,y
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0000
	LDA.w #$0003
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
