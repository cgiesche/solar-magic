
; Overworld sprite 05 - Cloud by yoshifanatic
; The cloud sprites seen flying overhead on the main map of the original SMW.
; Is set to spawn from the provided cloud generator.
; While you can place this, it's better to spawn it within another sprite's code or through a script.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_OWSpr05_Cloud_Palette = $02
!Define_SMW_OWSpr05_Cloud_Tile = $0044

EraseSprite:
	%erase_sprite()
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	LDA.w #$0020
	STA.w !RAM_SMW_OWSpr_XSpeed,x
	LDA.w #$FFF0
	STA.w !RAM_SMW_OWSpr_YSpeed,x
main:
	%sub_offscreen()
	BCS.b EraseSprite
if !bowsie_owrev == 1
	LDA.b !RAM_SMW_Flag_SpritesLocked
	BNE.b GFXRt
endif
	%sub_update_x_pos()
	%sub_update_y_pos()
GFXRt:
	LDA.w #$0001
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	STA.w oam_buffer[$00].x_pos,y
	CLC
	ADC.b #$10
	STA.w oam_buffer[$01].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	STA.w oam_buffer[$00].y_pos,y
	STA.w oam_buffer[$01].y_pos,y
	LDA.b #!Define_SMW_OWSpr05_Cloud_Tile
	STA.w oam_buffer[$00].tile,y
	STA.w oam_buffer[$01].tile,y
	LDA.b #(!Define_SMW_OWSpr05_Cloud_Tile<<8)|!Define_SMW_OWSpr05_Cloud_Palette|$30
	STA.w oam_buffer[$00].props,y
	ORA.b #$40
	STA.w oam_buffer[$01].props,y
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0002
	LDA.w #$0001
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
