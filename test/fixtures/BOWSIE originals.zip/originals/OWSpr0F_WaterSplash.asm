
; Overworld sprite 0F - Water Splash by yoshifanatic
; This will display a water splash effect, like how the cheep cheeps do in the original SMW, except no longer tied to that sprite.
; While you can place this, it's better to spawn it within another sprite's code or through a script.

incsrc "OriginalSMWSpriteDefines.asm"

!extra = 0

!Define_SMW_OWSpr0F_WaterSplash_Palette = $06
!Define_SMW_OWSpr0F_WaterSplash_Tile1 = $0073
!Define_SMW_OWSpr0F_WaterSplash_Tile2 = $0072
!Define_SMW_OWSpr0F_WaterSplash_Tile3 = $0063
!Define_SMW_OWSpr0F_WaterSplash_Tile4 = $0062

!RAM_SMW_OWSpr0F_WaterSplash_AnimationTimer #= !ow_sprite_timer_1

Tiles:
	dw !Define_SMW_OWSpr0F_WaterSplash_Tile1,!Define_SMW_OWSpr0F_WaterSplash_Tile2
	dw !Define_SMW_OWSpr0F_WaterSplash_Tile3,!Define_SMW_OWSpr0F_WaterSplash_Tile4

YDisp:
	dw $FFFF,$FFFF

EraseSprite:
	%erase_sprite()
	RTL

init:
if !bowsie_owrev == 1
	LDA.w #!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen
	STA.w !RAM_SMW_OWSpr_Properties,x
endif
	LDA.w #$0010
	STA.w !RAM_SMW_OWSpr0F_WaterSplash_AnimationTimer,x
main:
	%sub_offscreen()
	BCS.b EraseSprite
	LDA.w !RAM_SMW_OWSpr0F_WaterSplash_AnimationTimer,x
	BEQ.b EraseSprite
	LSR
	AND.w #$0006
	TAY
	LDA.w Tiles,y
	ORA.w #(!Define_SMW_OWSpr0F_WaterSplash_Palette&$30)<<8
	STA.b !RAM_SMW_Misc_ScratchRAM0E
	LDA.w #$0001
	SEC
	%get_draw_info()
	BCS.b .SpriteOffScreen
	%maxtile_set_databank()
	SEP.b #$20
	LDA.b !RAM_SMW_Misc_ScratchRAM00
	STA.w oam_buffer[$00].x_pos,y
	CLC
	ADC.b #$08
	STA.w oam_buffer[$01].x_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM02
	DEC
	STA.w oam_buffer[$00].y_pos,y
	STA.w oam_buffer[$01].y_pos,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0E
	STA.w oam_buffer[$00].tile,y
	STA.w oam_buffer[$01].tile,y
	LDA.b !RAM_SMW_Misc_ScratchRAM0F
	STA.w oam_buffer[$00].props,y
	ORA.b #$40
	STA.w oam_buffer[$01].props,y
	%maxtile_clear_databank()
	REP.b #$20
	LDX.w #$0000
	LDA.w #$0001
	%finish_oam_write()
.SpriteOffScreen:
	SEP.b #$10
	RTL
