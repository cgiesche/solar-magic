
; Sprite ID Defines (adjust these based on what slot you insert these sprites into. If using Overworld Revolution, copy these into its Define.asm file)
!Define_SMW_SpriteID_OWSpr01_Lakitu = $01
!Define_SMW_SpriteID_OWSpr02_BlueBird = $02
!Define_SMW_SpriteID_OWSpr03_CheepCheep = $03
!Define_SMW_SpriteID_OWSpr04_PiranhaPlant = $04
!Define_SMW_SpriteID_OWSpr05_Cloud = $05
!Define_SMW_SpriteID_OWSpr06_KoopaKid = $06
!Define_SMW_SpriteID_OWSpr07_Smoke = $07
!Define_SMW_SpriteID_OWSpr08_BowserSign = $08
!Define_SMW_SpriteID_OWSpr09_Bowser = $09
!Define_SMW_SpriteID_OWSpr0A_Boo = $0A
!Define_SMW_SpriteID_OWSpr0B_LevelAppearSparkle = $0B
!Define_SMW_SpriteID_OWSpr0C_FlyingSwitchBlock = $0C
!Define_SMW_SpriteID_OWSpr0D_EventFadeTile = $0D
!Define_SMW_SpriteID_OWSpr0E_DestroyTileSmoke = $0E
!Define_SMW_SpriteID_OWSpr0F_WaterSplash = $0F
!Define_SMW_SpriteID_OWSpr10_LightningGenerator = $10
!Define_SMW_SpriteID_OWSpr11_CloudGenerator = $11
!Define_SMW_SpriteID_OWSpr12_SpriteLevelTile = $12

; SA-1 variable defines
if !sa1 == 1
	!RAM_SMW_SA1_BeginSA1ProcessingRoutine = $001E80
	!RAM_SMW_SA1_SNESCodePointerLo = $000183
	!RAM_SMW_SA1_SNESCodePointerHi = !RAM_SMW_SA1_SNESCodePointerLo+$01
	!RAM_SMW_SA1_SNESCodePointerBank = !RAM_SMW_SA1_SNESCodePointerLo+$02
	!RAM_SMW_SA1_SNESDoneFlag = $00018A
	!RAM_SMW_OAM_MaxTileOAMBufferIndex1 = $003100
	!RAM_SMW_OAM_MaxTileOAMBufferIndex2 = $003102
	!REGISTER_SA1_SA1RQControlWrite = $002209
	!7F0000 = $418800
else
	!RAM_SMW_OAM_MaxTileOAMBufferIndex1 = $000B01
	!RAM_SMW_OAM_MaxTileOAMBufferIndex2 = $000B03
	!7F0000 = $7F0000
endif

; Overworld Revolution specific RAM (change if needed)
!RAM_SMW_OWPlayerLevelCollision_CurrentLayer #= $00000E|!dp
!RAM_SMW_Overworld_SpriteSpawnData #= $000FAA|!addr
!RAM_SMW_Overworld_EventRevealSpeed #= $0013E9|!addr
!RAM_SMW_OWSpr_EventFadeTileBufferIndex #= !7F0000
!RAM_SMW_OWSpr_EventFadeTileBuffer #= !7F0000+$02
	!RAM_SMW_OWSpr_EventFadeTileBuffer_XPos #= !RAM_SMW_OWSpr_EventFadeTileBuffer+$00
	!RAM_SMW_OWSpr_EventFadeTileBuffer_YPos #= !RAM_SMW_OWSpr_EventFadeTileBuffer+$02
	!RAM_SMW_OWSpr_EventFadeTileBuffer_NextTileDirection #= !RAM_SMW_OWSpr_EventFadeTileBuffer+$04
	!RAM_SMW_OWSpr_EventFadeTileBuffer_Map16Tile #= !RAM_SMW_OWSpr_EventFadeTileBuffer+$06
	!RAM_SMW_OWSpr_EventFadeTileBuffer_TilemapData #= !RAM_SMW_OWSpr_EventFadeTileBuffer+$08

; Original SMW RAM (Modified if Overworld Revolution is used)
!RAM_SMW_Overworld_EventFlags #= !event_flags
!RAM_SMW_Overworld_MarioYPosLo #= !mario_y_pos_lo
if !bowsie_owrev != 1
!RAM_SMW_Overworld_MarioGridAlignedXPosLo #= $001F1F|!addr
!RAM_SMW_Overworld_MarioGridAlignedXPosHi #= !RAM_SMW_Overworld_MarioGridAlignedXPosLo+$01
!RAM_SMW_Overworld_MarioGridAlignedYPosLo #= !RAM_SMW_Overworld_MarioGridAlignedXPosLo+$02
!RAM_SMW_Overworld_MarioGridAlignedYPosHi #= !RAM_SMW_Overworld_MarioGridAlignedXPosLo+$03
!RAM_SMW_Overworld_LuigiGridAlignedXPosLo #= !RAM_SMW_Overworld_MarioGridAlignedXPosLo+$04
!RAM_SMW_Overworld_LuigiGridAlignedXPosHi #= !RAM_SMW_Overworld_MarioGridAlignedXPosLo+$05
!RAM_SMW_Overworld_LuigiGridAlignedYPosLo #= !RAM_SMW_Overworld_MarioGridAlignedXPosLo+$06
!RAM_SMW_Overworld_LuigiGridAlignedYPosHi #= !RAM_SMW_Overworld_MarioGridAlignedXPosLo+$07
endif

; Original SMW RAM
!RAM_SMW_Misc_ScratchRAM00 #= $000000|!dp
!RAM_SMW_Misc_ScratchRAM01 #= $000001|!dp
!RAM_SMW_Misc_ScratchRAM02 #= $000002|!dp
!RAM_SMW_Misc_ScratchRAM03 #= $000003|!dp
!RAM_SMW_Misc_ScratchRAM04 #= $000004|!dp
!RAM_SMW_Misc_ScratchRAM05 #= $000005|!dp
!RAM_SMW_Misc_ScratchRAM06 #= $000006|!dp
!RAM_SMW_Misc_ScratchRAM07 #= $000007|!dp
!RAM_SMW_Misc_ScratchRAM08 #= $000008|!dp
!RAM_SMW_Misc_ScratchRAM09 #= $000009|!dp
!RAM_SMW_Misc_ScratchRAM0A #= $00000A|!dp
!RAM_SMW_Misc_ScratchRAM0B #= $00000B|!dp
!RAM_SMW_Misc_ScratchRAM0C #= $00000C|!dp
!RAM_SMW_Misc_ScratchRAM0D #= $00000D|!dp
!RAM_SMW_Misc_ScratchRAM0E #= $00000E|!dp
!RAM_SMW_Misc_ScratchRAM0F #= $00000F|!dp
!RAM_SMW_Counter_LocalFrames #= $000014|!dp
!RAM_SMW_Mirror_CurrentLayer1XPosLo #= $00001A|!dp
!RAM_SMW_Mirror_CurrentLayer1XPosHi #= !RAM_SMW_Mirror_CurrentLayer1XPosLo+$01
!RAM_SMW_Mirror_CurrentLayer1YPosLo #= !RAM_SMW_Mirror_CurrentLayer1XPosLo+$02
!RAM_SMW_Mirror_CurrentLayer1YPosHi #= !RAM_SMW_Mirror_CurrentLayer1YPosLo+$01
!RAM_SMW_Mirror_CurrentLayer2XPosLo #= !RAM_SMW_Mirror_CurrentLayer1XPosLo+$04
!RAM_SMW_Mirror_CurrentLayer2XPosHi #= !RAM_SMW_Mirror_CurrentLayer2XPosLo+$01
!RAM_SMW_Mirror_CurrentLayer2YPosLo #= !RAM_SMW_Mirror_CurrentLayer1XPosLo+$06
!RAM_SMW_Mirror_CurrentLayer2YPosHi #= !RAM_SMW_Mirror_CurrentLayer2YPosLo+$01
!RAM_SMW_Misc_ScratchRAM8A #= $00008A|!dp
!RAM_SMW_Misc_ScratchRAM8B #= $00008B|!dp
!RAM_SMW_Misc_ScratchRAM8C #= $00008C|!dp
!RAM_SMW_Misc_ScratchRAM8D #= $00008D|!dp
!RAM_SMW_Misc_ScratchRAM8E #= $00008E|!dp
!RAM_SMW_Misc_ScratchRAM8F #= $00008F|!dp
!RAM_SMW_Blocks_YPosLo #= $000098|!dp
!RAM_SMW_Blocks_YPosHi #= !RAM_SMW_Blocks_YPosLo+$01
!RAM_SMW_Blocks_XPosLo #= $00009A|!dp
!RAM_SMW_Blocks_XPosHi #= !RAM_SMW_Blocks_XPosLo+$01
!RAM_SMW_Flag_SpritesLocked #= $00009D|!dp
!RAM_SMW_Palettes_PaletteUploadTableIndex #= $000680|!addr
!RAM_SMW_Palettes_DynamicPaletteUploadIndex #= $000681|!addr
!RAM_SMW_Palettes_DynamicPaletteBytesToUpload #= $000682|!addr
!RAM_SMW_Palettes_DynamicPaletteCGRAMAddress #= !RAM_SMW_Palettes_DynamicPaletteBytesToUpload+$01
!RAM_SMW_Palettes_DynamicPaletteColors #= !RAM_SMW_Palettes_DynamicPaletteBytesToUpload+$02
!RAM_SMW_Palettes_PaletteMirror #= $000703|!addr
!RAM_SMW_Palettes_CopyOfPaletteMirror #= $000905|!addr
!RAM_SMW_Player_CurrentCharacterX4Lo #= $000DD6|!addr
!RAM_SMW_Sprites_CurrentlyProcessedOverworldSprite #= !ow_sprite_index
!RAM_SMW_OWSpr06_KoopaKid_ActivateFlag #= $000EF5|!addr
!RAM_SMW_OWSpr06_KoopaKid_TileIndex #= $000EF6|!addr
!RAM_SMW_Overworld_EnterLevelFlag #= $000EF7|!addr
!RAM_SMW_Misc_ColorOfPalaceSwitchPressed1 #= $0013D2|!addr
!RAM_SMW_Misc_RandomByte1 #= $00148D|!addr
!RAM_SMW_Misc_RandomByte2 #= !RAM_SMW_Misc_RandomByte1+$01
!RAM_SMW_Palettes_LevelEndColorFadeDirection #= $001494|!addr
!RAM_SMW_Timer_LevelEndFade #= $001495|!addr
!RAM_SMW_Misc_CurrentLayerBeingProcessedLo #= $001933|!addr
!RAM_SMW_Misc_CurrentLayerBeingProcessedHi #= !RAM_SMW_Misc_CurrentLayerBeingProcessedLo+$01
!RAM_SMW_IO_SoundCh1 #= $001DF9|!addr
!RAM_SMW_IO_SoundCh2 #= $001DFA|!addr
!RAM_SMW_IO_SoundCh3 #= $001DFC|!addr
!RAM_SMW_Palettes_LightningFlashColorIndex #= $001FFB|!addr
!RAM_SMW_Timer_WaitBeforeNextLightningFlash #= $001FFC|!addr
!RAM_SMW_Timer_LightningFrameDuration #= $001FFD|!addr
!RAM_SMW_Misc_StripeImageUploadIndexLo #= $7F837B
!RAM_SMW_Misc_StripeImageUploadIndexHi #= !RAM_SMW_Misc_StripeImageUploadIndexLo+$01

; Non-sprite specific overworld sprite tables

!RAM_SMW_OWSpr_SpriteID #= !ow_sprite_num
!RAM_SMW_OWSpr_CurrentState #= !ow_sprite_misc_5
!RAM_SMW_OWSpr_XSpeed #= !ow_sprite_speed_x
!RAM_SMW_OWSpr_YSpeed #= !ow_sprite_speed_y
!RAM_SMW_OWSpr_ZSpeed #= !ow_sprite_speed_z
!RAM_SMW_OWSpr_SubXPos #= !ow_sprite_speed_x_acc
!RAM_SMW_OWSpr_XPosLo #= !ow_sprite_x_pos
!RAM_SMW_OWSpr_XPosHi #= !RAM_SMW_OWSpr_XPosLo+$01
!RAM_SMW_OWSpr_SubYPos #= !ow_sprite_speed_y_acc
!RAM_SMW_OWSpr_YPosLo #= !ow_sprite_y_pos
!RAM_SMW_OWSpr_YPosHi #= !RAM_SMW_OWSpr_YPosLo+$01
!RAM_SMW_OWSpr_SubZPos #= !ow_sprite_speed_z_acc
!RAM_SMW_OWSpr_ZPosLo #= !ow_sprite_z_pos
!RAM_SMW_OWSpr_ZPosHi #= !RAM_SMW_OWSpr_ZPosLo+$01
if !bowsie_owrev == 1
!RAM_SMW_OWSpr_Properties #= !ow_sprite_props
endif
!RAM_SMW_OWSpr_ExtraByte1 #= !ow_sprite_extra_1
!RAM_SMW_OWSpr_ExtraByte2 #= !ow_sprite_extra_1+$01
!RAM_SMW_OWSpr_ExtraByte3 #= !ow_sprite_extra_2
!RAM_SMW_OWSpr_ExtraByte4 #= !ow_sprite_extra_2+$01

!RAM_SMW_OAM_MaxTileOAMBufferIndex1 #= !maxtile_oam_buffer_index_1
!RAM_SMW_OAM_MaxTileOAMBufferIndex2 #= !maxtile_oam_buffer_index_2

!Const_SMW_OffscreenBehaviorProp_DespawnOffscreen = $00
!Const_SMW_OffscreenBehaviorProp_ProcessWhenOffscreen = $01

; Original SMW routines/tables
SMW_GetRand_Main = $01ACF9|!bank
SMW_OverworldEventProcess04_FadeInLayer2Tile_CODE_00B006 = $00B006|!bank

; Overworld Revolution routines/tables
if !bowsie_owrev == 1
	BufferEventTile = read3($04811A+$01)
	GetEventIndex = read3($048122+$01)
	AdjustPaletteOfBufferedTiles = read3($04812A+$01)
	GetMap16TileFromLevelBuffer_EventEntry = read3($048132+$01)
	SMW_MaxtTile_Get_Slot = read3($048162+$01)
	DATA_04F6F8 = read3($04813A+$01)
	DATA_04F700 = read3($04813A+$01)+$08
	DATA_04F708 = read3($04813A+$01)+$10
	BufferOverworldSpriteTile = read3($04816A+$01)
else
	BufferEventTile = $000000
	AdjustPaletteOfBufferedTiles = $000000
	GetMap16TileFromLevelBuffer_EventEntry = $000000
	SMW_MaxtTile_Get_Slot = $000000|!bank
	DATA_04F6F8 = $04F6F8|!bank
	DATA_04F700 = $04F700|!bank
	DATA_04F708 = $04F708|!bank
	BufferOverworldSpriteTile = $000000|!bank
endif
SMW_ProcessOverworldSprites_Main = $048000|!bank

; Structs
struct SMW_CopyOfPaletteMirror !RAM_SMW_Palettes_CopyOfPaletteMirror
	.LowByte: skip $01
	.HighByte: skip $01
endstruct align $02

struct SMW_PaletteMirror !RAM_SMW_Palettes_PaletteMirror
	.LowByte: skip $01
	.HighByte: skip $01
endstruct align $02

; Temporary(?) defines
!RAM_SMW_DrawOWSprite_XPos = !RAM_SMW_Misc_ScratchRAM00
!RAM_SMW_DrawOWSprite_YPos = !RAM_SMW_Misc_ScratchRAM02
!RAM_SMW_DrawOWSprite_HighXBitAndTileSize = !RAM_SMW_Misc_ScratchRAM04
!RAM_SMW_DrawOWSprite_TileAndProp = !RAM_SMW_Misc_ScratchRAM06
!RAM_SMW_DrawOWSprite_CurrentFlip = !RAM_SMW_Misc_ScratchRAM0A
!RAM_SMW_DrawOWSprite_CurrentXDisp = !RAM_SMW_Misc_ScratchRAM0C
!RAM_SMW_DrawOWSprite_CurrentYDisp = !RAM_SMW_Misc_ScratchRAM0E
!RAM_SMW_DrawOWSprite_LoopCounter = !RAM_SMW_Misc_ScratchRAM8A

; Sound effect/music defines
!Define_SMW_Sound1DF9_HitHead = $01
!Define_SMW_Sound1DF9_Contact = $02
!Define_SMW_Sound1DF9_KickShell = $03
!Define_SMW_Sound1DF9_IntoPipe = $04
!Define_SMW_Sound1DF9_MidwayPoint = $05
!Define_SMW_Sound1DF9_YoshiGulp = $06
!Define_SMW_Sound1DF9_DryBonesCollapse = $07
!Define_SMW_Sound1DF9_SpinJumpKill = $08
!Define_SMW_Sound1DF9_FlyWithCape = $09
!Define_SMW_Sound1DF9_GetPowerup = $0A
!Define_SMW_Sound1DF9_ONOFFSwitch = $0B
!Define_SMW_Sound1DF9_CarryItemToGoal = $0C
!Define_SMW_Sound1DF9_GetCape = $0D
!Define_SMW_Sound1DF9_Swim = $0E
!Define_SMW_Sound1DF9_HurtWhileFlying = $0F
!Define_SMW_Sound1DF9_MagicShoot = $10
!Define_SMW_Sound1DF9_Pause = $11
!Define_SMW_Sound1DF9_UnPause = $12
!Define_SMW_Sound1DF9_Stomp1 = $13
!Define_SMW_Sound1DF9_Stomp2 = $14
!Define_SMW_Sound1DF9_Stomp3 = $15
!Define_SMW_Sound1DF9_Stomp4 = $16
!Define_SMW_Sound1DF9_Stomp5 = $17
!Define_SMW_Sound1DF9_Stomp6 = $18
!Define_SMW_Sound1DF9_Stomp7 = $19
!Define_SMW_Sound1DF9_Grinder1 = $1A
!Define_SMW_Sound1DF9_Grinder2 = $1B
!Define_SMW_Sound1DF9_YoshiCoin = $1C
!Define_SMW_Sound1DF9_RunningOutOfTime = $1D
!Define_SMW_Sound1DF9_PBalloon = $1E
!Define_SMW_Sound1DF9_KoopalingDead = $1F
!Define_SMW_Sound1DF9_YoshiSpit = $20
!Define_SMW_Sound1DF9_ValleyOfBowserAppears = $21
!Define_SMW_Sound1DF9_EndValleyOfBowserAppears = $22
!Define_SMW_Sound1DF9_LemmyWendyFall = $23
!Define_SMW_Sound1DF9_Unused = $24
!Define_SMW_Sound1DF9_BlarggRoar = $25
!Define_SMW_Sound1DF9_FireworksWhistle = $26
!Define_SMW_Sound1DF9_FireworksBang = $27
!Define_SMW_Sound1DF9_LouderFireworksWhistle = $28
!Define_SMW_Sound1DF9_LouderFireworksBang = $29
!Define_SMW_Sound1DF9_PeachPoppingOutOfClownCar = $2A
!Define_SMW_Sound1DF9_IncreaseMusicTempo = $FF

!Define_SMW_Sound1DFA_Jump = $01
!Define_SMW_Sound1DFA_TurnOnYoshiDrum = $02
!Define_SMW_Sound1DFA_TurnOffYoshiDrum = $03
!Define_SMW_Sound1DFA_Grinder = $04

!Define_SMW_Sound1DFC_Coin = $01
!Define_SMW_Sound1DFC_HitItemBlock = $02
!Define_SMW_Sound1DFC_HitVineBlock = $03
!Define_SMW_Sound1DFC_SpinJump = $04
!Define_SMW_Sound1DFC_1up = $05
!Define_SMW_Sound1DFC_ShootFireball = $06
!Define_SMW_Sound1DFC_BreakBlock = $07
!Define_SMW_Sound1DFC_Springboard = $08
!Define_SMW_Sound1DFC_BulletShoot = $09
!Define_SMW_Sound1DFC_EggHatch = $0A
!Define_SMW_Sound1DFC_PutItemInReserve = $0B
!Define_SMW_Sound1DFC_DropItemInReserve1 = $0C
!Define_SMW_Sound1DFC_DropItemInReserve2 = $0D
!Define_SMW_Sound1DFC_LRScroll = $0E
!Define_SMW_Sound1DFC_Door1 = $0F
!Define_SMW_Sound1DFC_Door2 = $10
!Define_SMW_Sound1DFC_DrumrollStart = $11
!Define_SMW_Sound1DFC_DrumrollEnd = $12
!Define_SMW_Sound1DFC_LoseYoshi = $13
!Define_SMW_Sound1DFC_Unused = $14
!Define_SMW_Sound1DFC_OverworldTileReveal = $15
!Define_SMW_Sound1DFC_CastleCollapse = $16
!Define_SMW_Sound1DFC_FireSpit = $17
!Define_SMW_Sound1DFC_Thunder = $18
!Define_SMW_Sound1DFC_Clap = $19
!Define_SMW_Sound1DFC_Explosion = $1A
!Define_SMW_Sound1DFC_TNTFuse = $1B
!Define_SMW_Sound1DFC_OverworldSwitchBlockEjection = $1C
!Define_SMW_Sound1DFC_RunningOutOfTime = $1D
!Define_SMW_Sound1DFC_ChuckWhistle = $1E
!Define_SMW_Sound1DFC_MountYoshi = $1F
!Define_SMW_Sound1DFC_LemmyWendyLandInLava = $20
!Define_SMW_Sound1DFC_YoshiTongue = $21
!Define_SMW_Sound1DFC_MessageBox = $22
!Define_SMW_Sound1DFC_StepOnLevelTile = $23
!Define_SMW_Sound1DFC_PSwitchRunningOut = $24
!Define_SMW_Sound1DFC_YoshiStompsEnemy = $25
!Define_SMW_Sound1DFC_Swooper = $26
!Define_SMW_Sound1DFC_Podoboo = $27
!Define_SMW_Sound1DFC_StunEnemy = $28
!Define_SMW_Sound1DFC_Correct = $29
!Define_SMW_Sound1DFC_Wrong = !Define_SMW_Sound1DFC_Correct+$01
!Define_SMW_Sound1DFC_FireworksWhistle = $2B
!Define_SMW_Sound1DFC_FireworksBang = $2C
!Define_SMW_Sound1DFC_PodobooPan1 = $2D
!Define_SMW_Sound1DFC_PodobooPan2 = $2E
!Define_SMW_Sound1DFC_PodobooPan3 = $2F
!Define_SMW_Sound1DFC_PodobooPan4 = $30
!Define_SMW_Sound1DFC_PodobooPan5 = $31
!Define_SMW_Sound1DFC_PodobooPan6 = $32
!Define_SMW_Sound1DFC_PodobooPan7 = $33
!Define_SMW_Sound1DFC_PodobooPan8 = $34
